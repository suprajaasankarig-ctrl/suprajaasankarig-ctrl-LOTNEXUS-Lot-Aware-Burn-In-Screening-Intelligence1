# LOTNEXUS — Lot-Aware Component Burn-In & Screening Intelligence

**SIH 2026 Problem Statement 26170 — AI-driven Component Burn-In & Screening Anomaly Detection**

## Project Overview

LOTNEXUS is a software decision-support prototype that identifies components which may become unsafe during burn-in **before** the final 168h screening point. It combines lot-specific robust statistics, statistical anomaly detection, Isolation Forest, gradient boosting (XGBoost-equivalent) 168h prediction, a multi-signal risk engine, and SHAP-style explainability.

## Problem Statement

Traditional burn-in screening asks: *Is the component value outside the datasheet specification?*

LOTNEXUS additionally asks:
1. *Is this component abnormal compared with other components from its own manufacturing lot?*
2. *Based on 0h, 24h, and 96h measurements, what is its predicted 168h behaviour?*

## Solution Architecture

```
Burn-In Dataset (Synthetic, Physics-Informed)
      ↓
Data Validation & Preprocessing
      ↓
Lot-Specific Baseline Engine (per-lot Median, MAD, IQR)
      ↓
 ┌─────────────────────────────┐
 │                             │
 ▼                             ▼
MODULE A                    MODULE B
Anomaly Detection           Drift Prediction
 │ Statistics (MAD/IQR)       │ Gradient Boosting (XGBoost-equivalent)
 │ Isolation Forest           │ 0h+24h+96h → 168h
 ▼                             ▼
Anomaly Score              Predicted 168h
 │                             │
 └──────────────┬──────────────┘
                ↓
           RISK ENGINE
           (weighted multi-signal)
                ↓
   PASS / MONITOR / EARLY REJECT
                ↓
       SHAP Explanation
                ↓
      Component Time Series
                ↓
          React Dashboard
```

## Key Innovations

1. **Lot-Aware Detection** — Each lot gets its own independent baseline (median, MAD, IQR). A component below the datasheet limit can still be flagged if it's highly abnormal relative to its lot.

2. **Early Drift Prediction** — Predicts 168h behaviour from 0h + 24h + 96h measurements using gradient boosting regression.

3. **False-Negative Risk Engine** — Combines anomaly evidence, lot deviation, predicted limit violation, and future drift into a transparent 0-100 risk score. Prioritizes recall over precision to avoid defect escape.

4. **Explainable Hybrid AI** — Robust Statistics + Isolation Forest + Gradient Boosting + SHAP-style feature attribution. Every decision comes with a human-readable explanation.

## Technology Stack

| Layer | Technology |
|-------|-----------|
| Frontend | React + TypeScript + Vite + Tailwind CSS |
| Database | PostgreSQL (Supabase) |
| ML/Stats | TypeScript implementations of Isolation Forest, Gradient Boosting, SHAP |
| Icons | Lucide React |
| Charts | Custom SVG components |

## Implementation Notes

This prototype implements all ML algorithms (Isolation Forest, Gradient Boosting, SHAP) natively in TypeScript rather than relying on a Python backend. This allows the entire pipeline to run client-side in the browser, with Supabase/PostgreSQL serving as the persistent data store for components, lots, predictions, and risk assessments.

### Why TypeScript ML?

- The deployment environment runs a Vite/React dev server with Supabase — no separate Python backend is needed.
- All algorithms are implemented from scratch with proper mathematical foundations.
- The Isolation Forest uses the exact algorithm from Liu et al. (2008) with path-length-based anomaly scoring.
- The gradient boosting model uses XGBoost-style tree building with regularization (L1/L2), min_child_weight, and early stopping.
- SHAP values are computed using exact Shapley value enumeration over all 2^4 coalitions of the four primary decision features.

## Project Structure

```
src/
├── lib/
│   ├── config.ts              — Central configuration (thresholds, weights, model params)
│   ├── types.ts               — Shared TypeScript type definitions
│   ├── dataGenerator.ts       — Physics-informed synthetic burn-in data generator
│   ├── statistics.ts          — Lot baselines: median, MAD, IQR, lot deviation
│   ├── isolationForest.ts     — Isolation Forest (from-scratch TypeScript)
│   ├── anomalyService.ts      — Statistical + IF combined anomaly score
│   ├── predictionService.ts   — Gradient boosting (XGBoost-equivalent) + linear baseline
│   ├── riskEngine.ts          — Multi-signal risk engine with PASS/MONITOR/EARLY_REJECT
│   ├── shapService.ts         — SHAP-style feature attribution (exact Shapley values)
│   ├── pipeline.ts            — Orchestrates full pipeline + Supabase seeding
│   ├── supabase.ts            — Supabase client singleton
│   └── uiHelpers.ts           — UI color/format helpers
├── components/
│   ├── Dashboard.tsx           — Overview with summary cards, distributions, lot table, high-risk
│   ├── ComponentSearch.tsx    — Search by component ID, lot, decision
│   ├── ComponentDetails.tsx   — Full analysis: header → decision → measurements → chart → baseline → anomaly → prediction → SHAP → reason
│   ├── LotAnalysis.tsx         — Lot-specific statistics and distribution histogram
│   ├── MetricsDashboard.tsx   — Model evaluation: MAE/RMSE/R², recall, FNR, F1, rescreening rate
│   ├── TimeSeriesChart.tsx    — SVG burn-in trajectory chart (observed + predicted + limit)
│   └── DonutChart.tsx          — SVG donut chart for distributions
├── App.tsx                    — Main app with navigation
├── main.tsx
└── index.css
```

## Dataset

The synthetic dataset is generated with a fixed random seed (42) for reproducibility. It contains:
- **10 lots** (LOT-01 through LOT-10), each with 50 components = 500 total
- **5 component types** with different parameter scales
- **12% base defect rate** (varies per lot: 8-18%)
- Physics-informed trajectories: 0h → 24h → 96h → 168h
- Defective components show accelerated drift, some exceed datasheet limits
- Normal components have bounded noise and slight drift
- Each lot has different base mean, spread, and drift rate

### Dataset Fields

| Field | Description |
|-------|-------------|
| component_id | Unique ID (C001-C500) |
| lot_id | Manufacturing lot (LOT-01 to LOT-10) |
| component_type | Component type |
| parameter_name | Measured parameter |
| nominal_value | Datasheet nominal value |
| datasheet_limit | Upper datasheet limit |
| temperature | Burn-in temperature (°C) |
| voltage | Burn-in voltage (V) |
| value_0h/24h/96h/168h | Measurements at each timepoint |
| manufacturing_shift | Shift (A/B/C) |
| test_date | Date of test |
| defect_label | Ground truth (normal/defective) |
| failure_type | Type of failure if defective |

## Lot Baseline Mathematics

For each lot, statistics are computed **independently** from only that lot's components:

- **Median**: Middle value of the lot's value_96h measurements
- **Mean Absolute Deviation (MAD)**: `MAD = mean(|x - mean(x)|)` — explicitly Mean Absolute Deviation, not Median Absolute Deviation
- **Q1, Q3, IQR**: 25th/75th percentiles and their difference

Lot deviation for each component:
- `robust_z = (value_96h - lot_median) / (MAD + epsilon)`
- Fallback: if MAD ≈ 0, use `IQR / 1.349` as scale estimator
- `iqr_deviation`, `iqr_position`, `absolute_lot_deviation`, `relative_lot_deviation`

## Module A — Anomaly Detection

Combines:
1. **Statistical anomaly score** — maps robust z-score and IQR deviation to 0-100 via sigmoid
2. **Isolation Forest** — 120 trees, contamination=0.12, trained on [value_0h, value_24h, value_96h, drift_0_to_24, drift_24_to_96, relative_lot_deviation]

Final anomaly score = 0.45 × statistical + 0.55 × isolation forest

Bands: Low (0-30), Moderate (31-60), High (61-80), Critical (81-100)

## Module B — Early Drift Prediction

**Features**: value_0h, value_24h, value_96h, drift_0_to_24, drift_24_to_96, total_drift_0_to_96
**Target**: value_168h

Never uses value_168h, defect_label, or failure_type as inputs.

Gradient boosting with:
- 150 estimators, max depth 4, learning rate 0.08
- L1/L2 regularization, min_child_weight=3
- 80/20 train/test split, early stopping on validation MAE
- Linear regression baseline for comparison

## Risk Engine

Weighted combination (weights in config.ts):
- 30% anomaly evidence
- 22% lot deviation evidence
- 28% predicted limit violation evidence
- 20% future drift evidence

Decisions:
- **PASS**: risk < 35
- **MONITOR**: 35 ≤ risk < 65
- **EARLY REJECT**: risk ≥ 65

## SHAP Explainability

Exact Shapley values computed over all 2^4 coalitions of:
- Lot Deviation
- Datasheet Limit
- Anomaly Score
- Predicted 168h

Each feature shows: actual value, SHAP contribution, direction (increased/reduced risk), and importance.

## Running the Project

```bash
# Install dependencies
npm install

# Start dev server (runs automatically in Bolt environment)
npm run dev

# Build for production
npm run build

# Type check
npm run typecheck
```

## Database

The Supabase PostgreSQL database is pre-provisioned. The schema (4 tables: lots, components, predictions, risk_assessments) is created via migration. RLS is enabled with anon+authenticated access since this is a no-auth prototype.

Click "Seed Database" in the app footer to populate the database with the synthetic dataset and all computed predictions/risk assessments.

## Evaluation Metrics

The Model Metrics page displays:
- **Prediction**: MAE, RMSE, R² for XGBoost vs Linear Regression
- **Classification**: Recall, False Negative Rate, Precision, F1
- **Screening**: Rescreening Rate = Monitor / Total

## Limitations

- Uses synthetic data, not real ISRO production data
- Does not physically prove latent defects — it is a decision-support tool
- SHAP values are computed for the explainable risk function, not the raw gradient boosting model
- Results do not represent actual aerospace/spacecraft qualification performance

## Future Improvements

- Real dataset integration
- Deep learning models (LSTM/Transformer) for time-series prediction
- Real-time streaming burn-in data ingestion
- Multi-parameter joint analysis
- Automated retraining pipeline
