// LOTNEXUS — Lot-Aware Component Burn-In & Screening Intelligence
// SIH 2026 Problem Statement 26170 — AI-driven Component Burn-In & Screening Anomaly Detection
//
// Full pipeline: synthetic data → lot baselines → Module A (anomaly) → Module B (prediction)
// → Risk Engine → SHAP explanation → time-series → React dashboard

import { useState, useEffect } from 'react';
import { Cpu, LayoutDashboard, Boxes, BarChart3, Database, Loader2, CheckCircle2, AlertCircle } from 'lucide-react';
import { Dashboard } from '@/components/Dashboard';
import { ComponentDetails } from '@/components/ComponentDetails';
import { ComponentSearch } from '@/components/ComponentSearch';
import { LotAnalysis } from '@/components/LotAnalysis';
import { MetricsDashboard } from '@/components/MetricsDashboard';
import { seedDatabase } from '@/lib/pipeline';

type View = 'dashboard' | 'component' | 'search' | 'lots' | 'metrics';

export default function App() {
  const [view, setView] = useState<View>('dashboard');
  const [selectedComponent, setSelectedComponent] = useState<string>('');
  const [seedStatus, setSeedStatus] = useState<'idle' | 'seeding' | 'done' | 'error'>('idle');
  const [seedMessage, setSeedMessage] = useState('');

  const handleSelectComponent = (id: string) => {
    setSelectedComponent(id);
    setView('component');
  };

  const handleSeed = async () => {
    setSeedStatus('seeding');
    const result = await seedDatabase();
    setSeedMessage(result.message);
    setSeedStatus(result.success ? 'done' : 'error');
  };

  const navItems: { id: View; label: string; icon: React.ReactNode }[] = [
    { id: 'dashboard', label: 'Overview', icon: <LayoutDashboard className="w-4 h-4" /> },
    { id: 'search', label: 'Components', icon: <Cpu className="w-4 h-4" /> },
    { id: 'lots', label: 'Lots', icon: <Boxes className="w-4 h-4" /> },
    { id: 'metrics', label: 'Model Metrics', icon: <BarChart3 className="w-4 h-4" /> },
  ];

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100">
      {/* Header */}
      <header className="border-b border-slate-800 bg-slate-900/80 backdrop-blur-sm sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            {/* Logo */}
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-lg bg-gradient-to-br from-blue-500 to-cyan-500 flex items-center justify-center">
                <Cpu className="w-6 h-6 text-white" />
              </div>
              <div>
                <h1 className="text-lg font-bold text-white tracking-tight">LOTNEXUS</h1>
                <p className="text-xs text-slate-400 -mt-0.5">Lot-Aware Burn-In Screening Intelligence</p>
              </div>
            </div>

            {/* Navigation */}
            <nav className="flex items-center gap-1">
              {navItems.map((item) => (
                <button
                  key={item.id}
                  onClick={() => setView(item.id)}
                  className={`flex items-center gap-2 px-3 py-2 rounded-lg text-sm font-medium transition-colors ${
                    view === item.id
                      ? 'bg-blue-500/10 text-blue-400 border border-blue-500/30'
                      : 'text-slate-400 hover:text-white hover:bg-slate-800/50 border border-transparent'
                  }`}
                >
                  {item.icon}
                  <span className="hidden sm:inline">{item.label}</span>
                </button>
              ))}
            </nav>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
        {view === 'dashboard' && (
          <Dashboard
            onSelectComponent={handleSelectComponent}
            onNavigateLots={() => setView('lots')}
          />
        )}
        {view === 'component' && (
          <ComponentDetails
            componentId={selectedComponent}
            onBack={() => setView('dashboard')}
          />
        )}
        {view === 'search' && (
          <ComponentSearch onSelectComponent={handleSelectComponent} />
        )}
        {view === 'lots' && (
          <LotAnalysis onBack={() => setView('dashboard')} onSelectComponent={handleSelectComponent} />
        )}
        {view === 'metrics' && (
          <MetricsDashboard onBack={() => setView('dashboard')} />
        )}
      </main>

      {/* Database Seed Footer */}
      <footer className="border-t border-slate-800 bg-slate-900/50 mt-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <div className="flex flex-col sm:flex-row items-center justify-between gap-3">
            <div className="flex items-center gap-2 text-sm text-slate-400">
              <Database className="w-4 h-4" />
              <span>PostgreSQL via Supabase — {seedStatus === 'done' ? 'Seeded' : seedStatus === 'error' ? 'Seed failed' : 'Not seeded'}</span>
            </div>
            <div className="flex items-center gap-3">
              {seedStatus === 'done' && (
                <span className="flex items-center gap-1.5 text-sm text-emerald-400">
                  <CheckCircle2 className="w-4 h-4" /> {seedMessage}
                </span>
              )}
              {seedStatus === 'error' && (
                <span className="flex items-center gap-1.5 text-sm text-red-400">
                  <AlertCircle className="w-4 h-4" /> {seedMessage}
                </span>
              )}
              <button
                onClick={handleSeed}
                disabled={seedStatus === 'seeding'}
                className="flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-medium bg-slate-800 text-slate-200 border border-slate-700 hover:bg-slate-700 disabled:opacity-50 transition-colors"
              >
                {seedStatus === 'seeding' ? (
                  <><Loader2 className="w-4 h-4 animate-spin" /> Seeding...</>
                ) : (
                  <><Database className="w-4 h-4" /> Seed Database</>
                )}
              </button>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}
