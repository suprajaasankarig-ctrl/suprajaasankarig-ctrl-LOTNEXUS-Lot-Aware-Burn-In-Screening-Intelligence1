// LOTNEXUS — Model Run Metadata

export interface ModelRun {
  run_id: string;
  started_at: string;
  completed_at: string;
  dataset_size: number;
  train_size: number;
  validation_size: number;
  test_size: number;
  random_seed: number;

  model_name: string;
  model_version: string;

  mae: number;
  rmse: number;
  r2: number;

  precision: number;
  recall: number;
  f1: number;
  false_negative_rate: number;

  notes: string;
}

export function createRunId(): string {
  return `RUN-${Date.now()}`;
}

export function createModelRun(
  values: Omit<ModelRun, 'run_id'>,
): ModelRun {
  return {
    run_id: createRunId(),
    ...values,
  };
}