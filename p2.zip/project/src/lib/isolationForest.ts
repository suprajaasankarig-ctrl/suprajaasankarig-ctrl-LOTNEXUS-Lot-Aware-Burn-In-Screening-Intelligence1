// LOTNEXUS — Isolation Forest (from-scratch TypeScript implementation)
// Implements the Isolation Forest algorithm for anomaly detection.
// Reference: Liu, Ting & Zhou (2008) "Isolation Forest"
//
// Normalization: the raw anomaly score s is transformed so 0 = very normal, 100 = highly anomalous.
// scikit-learn's IsolationForest returns decision_function in range roughly [-0.5, +0.5] where
// higher = more normal. We invert and scale: anomaly_score_0_100 = (0.5 - decision) / 1.0 * 100, clamped [0, 100].

import { CONFIG } from './config';
import type { RawComponent, LotBaseline } from './types';

// --- Mulberry32 PRNG for reproducibility ---
function mulberry32(seed: number) {
  let s = seed >>> 0;
  return function () {
    s = (s + 0x6d2b79f5) >>> 0;
    let t = s;
    t = Math.imul(t ^ (t >>> 15), t | 1);
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

// --- iTree / iForest ---

interface ITreeNode {
  isLeaf: boolean;
  splitAttr: number;
  splitValue: number;
  left: ITreeNode | null;
  right: ITreeNode | null;
  size: number;
}

interface IsolationForestModel {
  trees: ITreeNode[];
  nEstimators: number;
  maxSamples: number;
  subsampleSize: number;
  cNorm: number; // c(n) normalization constant
}

// c(n) — expected path length of unsuccessful BST search
function expectedPathLength(n: number): number {
  if (n <= 1) return 0;
  if (n === 2) return 1;
  return 2 * (Math.log(n - 1) + 0.5772156649) - (2 * (n - 1)) / n;
}

function buildITree(
  data: number[][],
  rng: () => number,
  depth: number,
  maxDepth: number
): ITreeNode {
  const n = data.length;

  if (n <= 1 || depth >= maxDepth) {
    return { isLeaf: true, splitAttr: -1, splitValue: 0, left: null, right: null, size: n };
  }

  // Pick a random attribute
  const numFeatures = data[0].length;
  const attr = Math.floor(rng() * numFeatures);

  // Find min/max for this attribute
  let min = Infinity, max = -Infinity;
  for (const row of data) {
    if (row[attr] < min) min = row[attr];
    if (row[attr] > max) max = row[attr];
  }

  if (max - min < CONFIG.EPSILON) {
    return { isLeaf: true, splitAttr: -1, splitValue: 0, left: null, right: null, size: n };
  }

  // Random split between min and max
  const splitValue = min + rng() * (max - min);

  const leftData: number[][] = [];
  const rightData: number[][] = [];
  for (const row of data) {
    if (row[attr] < splitValue) leftData.push(row);
    else rightData.push(row);
  }

  return {
    isLeaf: false,
    splitAttr: attr,
    splitValue,
    left: buildITree(leftData, rng, depth + 1, maxDepth),
    right: buildITree(rightData, rng, depth + 1, maxDepth),
    size: n,
  };
}

function pathLength(node: ITreeNode, point: number[], depth: number): number {
  if (node.isLeaf) {
    return depth + expectedPathLength(node.size);
  }
  if (point[node.splitAttr] < node.splitValue) {
    return pathLength(node.left!, point, depth + 1);
  } else {
    return pathLength(node.right!, point, depth + 1);
  }
}

// --- Feature extraction for Isolation Forest ---

export interface IFFeatures {
  value_0h: number;
  value_24h: number;
  value_96h: number;
  drift_0_to_24: number;
  drift_24_to_96: number;
  relative_lot_deviation: number;
}

export function extractIFFeatures(
  component: RawComponent,
  baseline: LotBaseline
): number[] {
  const drift0to24 = component.value_24h - component.value_0h;
  const drift24to96 = component.value_96h - component.value_24h;
  const relativeDeviation = baseline.median > CONFIG.EPSILON
    ? Math.abs(component.value_96h - baseline.median) / Math.abs(baseline.median)
    : 0;

  return [
    component.value_0h,
    component.value_24h,
    component.value_96h,
    drift0to24,
    drift24to96,
    relativeDeviation,
  ];
}

// --- Train Isolation Forest ---

export function trainIsolationForest(
  components: RawComponent[],
  baselines: LotBaseline[]
): IsolationForestModel {
  const rng = mulberry32(CONFIG.ISOLATION_FOREST.randomState);
  const { nEstimators, maxSamples } = CONFIG.ISOLATION_FOREST;

  // Build feature matrix
  const baselineMap = new Map(baselines.map((b) => [b.lot_id, b]));
  const featureMatrix = components.map((c) =>
    extractIFFeatures(c, baselineMap.get(c.lot_id)!)
  );

  const n = featureMatrix.length;
  const subsampleSize = Math.min(maxSamples, n);
  const maxDepth = Math.ceil(Math.log2(Math.max(subsampleSize, 2)));
  const cNorm = expectedPathLength(subsampleSize);

  const trees: ITreeNode[] = [];

  for (let i = 0; i < nEstimators; i++) {
    // Subsample
    const indices: number[] = [];
    for (let j = 0; j < subsampleSize; j++) {
      indices.push(Math.floor(rng() * n));
    }
    const subsample = indices.map((idx) => featureMatrix[idx]);
    trees.push(buildITree(subsample, rng, 0, maxDepth));
  }

  return { trees, nEstimators, maxSamples, subsampleSize, cNorm };
}

// --- Score a single component ---

export function scoreIsolationForest(
  model: IsolationForestModel,
  features: number[]
): { raw_score: number; anomaly_score_0_100: number; is_anomaly: boolean } {
  // Average path length across all trees
  let avgPath = 0;
  for (const tree of model.trees) {
    avgPath += pathLength(tree, features, 0);
  }
  avgPath /= model.trees.length;

  // Anomaly score: s = 2^(-E(h) / c(n))
  // s close to 1 → anomaly, s close to 0.5 → normal
  const s = Math.pow(2, -avgPath / (model.cNorm + CONFIG.EPSILON));

  // Transform to 0-100 where 100 = highly anomalous
  // s ∈ (0, 1), where s > 0.5 → anomalous, s < 0.5 → normal (for contamination ~0.1)
  // We use: anomaly_0_100 = (s - 0.4) / (1.0 - 0.4) * 100, clamped
  // This maps s=0.4 → 0 (normal) and s=1.0 → 100 (max anomaly)
  let anomalyScore = ((s - 0.4) / 0.6) * 100;
  anomalyScore = Math.max(0, Math.min(100, anomalyScore));

  // Is anomaly if s > threshold (scikit-learn uses offset of -0.5 on decision_function)
  // Equivalent: s > 0.6 for contamination ~0.12
  const isAnomaly = s > 0.607;

  return {
    raw_score: Math.round(s * 10000) / 10000,
    anomaly_score_0_100: Math.round(anomalyScore * 100) / 100,
    is_anomaly: isAnomaly,
  };
}

// --- Train and score all components ---

export interface IsolationForestResult {
  model: IsolationForestModel;
  scores: Map<string, { raw_score: number; anomaly_score_0_100: number; is_anomaly: boolean }>;
}

export function trainAndScoreIsolationForest(
  components: RawComponent[],
  baselines: LotBaseline[]
): IsolationForestResult {
  const model = trainIsolationForest(components, baselines);
  const baselineMap = new Map(baselines.map((b) => [b.lot_id, b]));
  const scores = new Map<string, { raw_score: number; anomaly_score_0_100: number; is_anomaly: boolean }>();

  for (const c of components) {
    const features = extractIFFeatures(c, baselineMap.get(c.lot_id)!);
    scores.set(c.component_id, scoreIsolationForest(model, features));
  }

  return { model, scores };
}
