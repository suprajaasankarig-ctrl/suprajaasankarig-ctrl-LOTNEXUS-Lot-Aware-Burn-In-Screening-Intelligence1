// LOTNEXUS — Physics-Informed Synthetic Burn-In Data Generator
// Generates reproducible synthetic burn-in data with lot-to-lot variation,
// normal/defective trajectories, measurement noise, and drift patterns.

import { CONFIG, DATASET_CONFIG } from './config';
import type { RawComponent } from './types';

// Mulberry32 PRNG — deterministic, reproducible
function mulberry32(seed: number) {
  let s = seed >>> 0;
  return function () {
    s = (s + 0x6d2b79f5) >>> 0;
    let t = s;
    t = Math.imul(t ^ (t >>> 15), t | 1);
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

// Box-Muller transform for Gaussian noise
function gaussian(rng: () => number, mean: number, std: number): number {
  const u1 = Math.max(rng(), 1e-10);
  const u2 = rng();
  const z = Math.sqrt(-2 * Math.log(u1)) * Math.cos(2 * Math.PI * u2);
  return mean + z * std;
}

// Lot profile — each lot has its own normal behaviour
interface LotProfile {
  lot_id: string;
  component_type: string;
  parameter_name: string;
  nominal_value: number;
  datasheet_limit: number;
  lot_base_mean: number; // lot-specific central tendency
  lot_spread: number; // lot-specific variation
  drift_rate: number; // normal drift per hour for this lot
  temperature: number;
  voltage: number;
}

function buildLotProfiles(): LotProfile[] {
  const rng = mulberry32(DATASET_CONFIG.randomSeed);
  const profiles: LotProfile[] = [];

  for (let i = 0; i < DATASET_CONFIG.numLots; i++) {
    const typeIdx = i % DATASET_CONFIG.componentTypes.length;
    const paramIdx = i % DATASET_CONFIG.parameterNames.length;
    const componentType = DATASET_CONFIG.componentTypes[typeIdx];
    const parameterName = DATASET_CONFIG.parameterNames[paramIdx];

    // Each parameter has a different scale
    const { nominal, limit } = getParameterScale(parameterName);

    // Lot-to-lot variation: different lots have different base means
    // Some lots are "tight" (low spread), some are "loose"
    const lotBaseMean = nominal * (0.9 + rng() * 0.25); // ±10-15% from nominal
    const lotSpread = nominal * (0.01 + rng() * 0.04); // 1-5% spread
    const driftRate = nominal * (0.0001 + rng() * 0.0003); // small drift per hour

    profiles.push({
      lot_id: `LOT-${String(i + 1).padStart(2, '0')}`,
      component_type: componentType,
      parameter_name: parameterName,
      nominal_value: nominal,
      datasheet_limit: limit,
      lot_base_mean: lotBaseMean,
      lot_spread: lotSpread,
      drift_rate: driftRate,
      temperature: DATASET_CONFIG.temperatures[i % DATASET_CONFIG.temperatures.length],
      voltage: DATASET_CONFIG.voltages[i % DATASET_CONFIG.voltages.length],
    });
  }

  return profiles;
}

function getParameterScale(param: string): { nominal: number; limit: number } {
  switch (param) {
    case 'leakage_current':
      return { nominal: 10.0, limit: 50.0 }; // µA, upper limit
    case 'offset_voltage':
      return { nominal: 2.0, limit: 10.0 }; // mV
    case 'breakdown_voltage':
      return { nominal: 75.0, limit: 100.0 }; // V, must stay above minimum
    case 'threshold_voltage':
      return { nominal: 3.3, limit: 5.0 }; // V
    case 'insulation_resistance':
      return { nominal: 100.0, limit: 500.0 }; // MΩ
    default:
      return { nominal: 10.0, limit: 50.0 };
  }
}

// Failure types for defective components
const FAILURE_TYPES = [
  'gradual_drift',
  'early_degradation',
  'thermal_runaway',
  'parametric_shift',
  'excessive_leakage',
];

export function generateSyntheticData(): RawComponent[] {
  const rng = mulberry32(DATASET_CONFIG.randomSeed);
  const profiles = buildLotProfiles();
  const components: RawComponent[] = [];

  let componentCounter = 0;

  for (const profile of profiles) {
    const numComponents = DATASET_CONFIG.componentsPerLot;
    // Each lot has a different defect rate (8-18%)
    const lotDefectRate = DATASET_CONFIG.defectRate * (0.7 + rng() * 0.6);
    const numDefective = Math.round(numComponents * lotDefectRate);

    // Determine which components are defective
    const defectiveIndices = new Set<number>();
    while (defectiveIndices.size < numDefective) {
      defectiveIndices.add(Math.floor(rng() * numComponents));
    }

    for (let j = 0; j < numComponents; j++) {
      componentCounter++;
      const isDefective = defectiveIndices.has(j);
      const componentId = `C${String(componentCounter).padStart(3, '0')}`;

      // Starting value — normally distributed around lot base mean
      const startValue = gaussian(rng, profile.lot_base_mean, profile.lot_spread);

      let value0h: number, value24h: number, value96h: number, value168h: number;
      let failureType = 'none';
      let defectLabel: 'normal' | 'defective' = 'normal';

      if (isDefective) {
        defectLabel = 'defective';
        failureType = FAILURE_TYPES[Math.floor(rng() * FAILURE_TYPES.length)];

        // Different failure modes produce different trajectories
        const driftMultiplier = 2 + rng() * 4; // 2x-6x normal drift
        const acceleration = 1 + rng() * 0.8; // drift accelerates over time

        // Some defects start near the lot mean, some start already shifted
        const initialOffset = rng() < 0.4 ? profile.lot_spread * (1 + rng() * 2) : 0;
        const direction = rng() < 0.85 ? 1 : -1; // mostly upward drift

        value0h = startValue + initialOffset * direction;
        value24h = value0h + profile.drift_rate * 24 * driftMultiplier * direction;
        value96h = value24h + profile.drift_rate * 72 * driftMultiplier * acceleration * direction;
        value168h = value96h + profile.drift_rate * 72 * driftMultiplier * acceleration * 1.5 * direction;

        // Some defective components exceed the datasheet limit
        if (rng() < 0.35) {
          // Push past the limit
          const overshoot = profile.datasheet_limit * (0.02 + rng() * 0.15);
          value168h = profile.datasheet_limit + overshoot;
          // Adjust intermediate values to be consistent
          const totalDrift = value168h - value0h;
          value24h = value0h + totalDrift * 0.15;
          value96h = value0h + totalDrift * 0.45;
        }
      } else {
        // Normal component — bounded noise, slight drift
        const normalDrift = profile.drift_rate;
        value0h = startValue;
        value24h = value0h + gaussian(rng, normalDrift * 24, profile.lot_spread * 0.15);
        value96h = value24h + gaussian(rng, normalDrift * 72, profile.lot_spread * 0.2);
        value168h = value96h + gaussian(rng, normalDrift * 72, profile.lot_spread * 0.25);
      }

      // Add measurement noise (small, consistent across all measurements)
      const noiseLevel = Math.abs(profile.nominal_value) * 0.002;
      value0h += gaussian(rng, 0, noiseLevel);
      value24h += gaussian(rng, 0, noiseLevel);
      value96h += gaussian(rng, 0, noiseLevel);
      value168h += gaussian(rng, 0, noiseLevel);

      // Ensure no NaN/Inf
      value0h = sanitize(value0h);
      value24h = sanitize(value24h);
      value96h = sanitize(value96h);
      value168h = sanitize(value168h);

      const shift = DATASET_CONFIG.shifts[Math.floor(rng() * DATASET_CONFIG.shifts.length)];
      const testDate = new Date(2026, 7 + Math.floor(componentCounter / 100), 1 + (componentCounter % 28))
        .toISOString()
        .split('T')[0];

      components.push({
        component_id: componentId,
        lot_id: profile.lot_id,
        component_type: profile.component_type,
        parameter_name: profile.parameter_name,
        nominal_value: profile.nominal_value,
        datasheet_limit: profile.datasheet_limit,
        temperature: profile.temperature,
        voltage: profile.voltage,
        value_0h: round(value0h, 4),
        value_24h: round(value24h, 4),
        value_96h: round(value96h, 4),
        value_168h: round(value168h, 4),
        manufacturing_shift: shift,
        test_date: testDate,
        defect_label: defectLabel,
        failure_type: failureType,
      });
    }
  }

  return components;
}

function sanitize(v: number): number {
  if (!Number.isFinite(v)) return 0;
  return v;
}

function round(v: number, decimals: number): number {
  const f = Math.pow(10, decimals);
  return Math.round(v * f) / f;
}

// Export for use in other modules
export { buildLotProfiles };
export type { LotProfile };
