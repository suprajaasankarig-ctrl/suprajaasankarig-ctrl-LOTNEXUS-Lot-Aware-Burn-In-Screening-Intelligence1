// LOTNEXUS — Risk Engine
// Combines lot deviation, anomaly score, predicted 168h, and datasheet limit relationship
// into a transparent 0-100 risk score with PASS / MONITOR / EARLY_REJECT decisions.
// Weights are configurable in config.ts and NOT scattered as magic numbers.

import { CONFIG } from './config';
import type {
  RawComponent,
  LotBaseline,
  LotDeviation,
  AnomalyResult,
  PredictionResult,
  RiskResult,
  RiskFactor,
} from './types';

export function calculateRisk(
  component: RawComponent,
  baseline: LotBaseline,
  deviation: LotDeviation,
  anomaly: AnomalyResult,
  prediction: PredictionResult
): RiskResult {
  const weights = CONFIG.RISK_WEIGHTS;

  // --- Component 1: Anomaly evidence (0-100) ---
  const anomalyComponent = anomaly.anomaly_score;

  // --- Component 2: Lot deviation evidence (0-100) ---
  const absZ = Math.abs(deviation.robust_z);
  let lotDeviationComponent: number;
  if (absZ >= CONFIG.LOT_DEVIATION.high) {
    lotDeviationComponent = Math.min(100, 60 + (absZ - CONFIG.LOT_DEVIATION.high) * 8);
  } else if (absZ >= CONFIG.LOT_DEVIATION.moderate) {
    lotDeviationComponent = 30 + ((absZ - CONFIG.LOT_DEVIATION.moderate) / (CONFIG.LOT_DEVIATION.high - CONFIG.LOT_DEVIATION.moderate)) * 30;
  } else {
    lotDeviationComponent = (absZ / CONFIG.LOT_DEVIATION.moderate) * 30;
  }
  lotDeviationComponent = Math.min(100, Math.max(0, lotDeviationComponent));

  // --- Component 3: Predicted limit violation evidence (0-100) ---
  const limitRatio = prediction.predicted_limit_ratio;
  let predictedLimitComponent: number;
  if (limitRatio >= CONFIG.PREDICTED_MARGIN.violationRatio) {
    // Exceeds datasheet limit
    predictedLimitComponent = Math.min(100, 70 + (limitRatio - 1.0) * 150);
  } else if (limitRatio >= CONFIG.PREDICTED_MARGIN.warningRatio) {
    // Approaching limit
    predictedLimitComponent = 30 + ((limitRatio - CONFIG.PREDICTED_MARGIN.warningRatio) / (1.0 - CONFIG.PREDICTED_MARGIN.warningRatio)) * 40;
  } else {
    // Well within limit
    predictedLimitComponent = Math.max(0, (limitRatio / CONFIG.PREDICTED_MARGIN.warningRatio) * 30);
  }
  predictedLimitComponent = Math.min(100, Math.max(0, predictedLimitComponent));

  // --- Component 4: Future drift evidence (0-100) ---
  const driftRatio = Math.abs(prediction.predicted_drift_96_168) / Math.max(Math.abs(component.nominal_value), CONFIG.EPSILON);
  let futureDriftComponent: number;
  if (driftRatio >= CONFIG.FUTURE_DRIFT.high) {
    futureDriftComponent = Math.min(100, 60 + (driftRatio - CONFIG.FUTURE_DRIFT.high) * 400);
  } else if (driftRatio >= CONFIG.FUTURE_DRIFT.moderate) {
    futureDriftComponent = 30 + ((driftRatio - CONFIG.FUTURE_DRIFT.moderate) / (CONFIG.FUTURE_DRIFT.high - CONFIG.FUTURE_DRIFT.moderate)) * 30;
  } else {
    futureDriftComponent = (driftRatio / CONFIG.FUTURE_DRIFT.moderate) * 30;
  }
  futureDriftComponent = Math.min(100, Math.max(0, futureDriftComponent));

  // --- Weighted risk score ---
  const riskScore =
    weights.anomaly * anomalyComponent +
    weights.lotDeviation * lotDeviationComponent +
    weights.predictedLimit * predictedLimitComponent +
    weights.futureDrift * futureDriftComponent;

  const risk = Math.round(Math.min(100, Math.max(0, riskScore)) * 100) / 100;

  // --- Decision ---
  let decision: 'PASS' | 'MONITOR' | 'EARLY_REJECT';
  if (risk >= CONFIG.EARLY_REJECT_THRESHOLD) {
    decision = 'EARLY_REJECT';
  } else if (risk >= CONFIG.MONITOR_THRESHOLD) {
    decision = 'MONITOR';
  } else {
    decision = 'PASS';
  }

  // --- Risk factors (dynamically generated) ---
  const riskFactors = generateRiskFactors(
    deviation, anomaly, prediction, component, baseline
  );

  // --- Decision reason (dynamically generated) ---
  const decisionReason = generateDecisionReason(decision, riskFactors, risk);

  return {
    risk_score: risk,
    decision,
    decision_reason: decisionReason,
    risk_factors: riskFactors,
    risk_components: {
      anomaly_component: Math.round(anomalyComponent * 100) / 100,
      lot_deviation_component: Math.round(lotDeviationComponent * 100) / 100,
      predicted_limit_component: Math.round(predictedLimitComponent * 100) / 100,
      future_drift_component: Math.round(futureDriftComponent * 100) / 100,
    },
  };
}

function generateRiskFactors(
  deviation: LotDeviation,
  anomaly: AnomalyResult,
  prediction: PredictionResult,
  component: RawComponent,
  _baseline: LotBaseline
): RiskFactor[] {
  const factors: RiskFactor[] = [];

  // Lot deviation
  const absZ = Math.abs(deviation.robust_z);
  if (absZ >= CONFIG.LOT_DEVIATION.high) {
    factors.push({
      factor: 'Lot Deviation',
      value: `${deviation.robust_z.toFixed(2)}σ`,
      severity: 'high',
      description: `High lot-relative deviation (${absZ.toFixed(2)} robust z-score from lot median)`,
    });
  } else if (absZ >= CONFIG.LOT_DEVIATION.moderate) {
    factors.push({
      factor: 'Lot Deviation',
      value: `${deviation.robust_z.toFixed(2)}σ`,
      severity: 'moderate',
      description: `Moderate lot-relative deviation (${absZ.toFixed(2)} robust z-score from lot median)`,
    });
  }

  // Anomaly score
  if (anomaly.anomaly_score >= CONFIG.ANOMALY_HIGH) {
    factors.push({
      factor: 'Anomaly Score',
      value: `${anomaly.anomaly_score.toFixed(1)}/100`,
      severity: 'critical',
      description: `High anomaly score (${anomaly.anomaly_band} band, statistical=${anomaly.statistical_score.toFixed(1)}, IF=${anomaly.isolation_forest_score.toFixed(1)})`,
    });
  } else if (anomaly.anomaly_score >= CONFIG.ANOMALY_MODERATE) {
    factors.push({
      factor: 'Anomaly Score',
      value: `${anomaly.anomaly_score.toFixed(1)}/100`,
      severity: 'moderate',
      description: `Moderate anomaly score (${anomaly.anomaly_band} band)`,
    });
  }

  // Predicted 168h vs datasheet limit
  if (prediction.predicted_limit_ratio >= CONFIG.PREDICTED_MARGIN.violationRatio) {
    factors.push({
      factor: 'Predicted 168h',
      value: `${prediction.predicted_168h.toFixed(2)}`,
      severity: 'critical',
      description: `Predicted 168h (${prediction.predicted_168h.toFixed(2)}) exceeds datasheet limit (${component.datasheet_limit.toFixed(2)})`,
    });
  } else if (prediction.predicted_limit_ratio >= CONFIG.PREDICTED_MARGIN.warningRatio) {
    factors.push({
      factor: 'Predicted 168h',
      value: `${prediction.predicted_168h.toFixed(2)}`,
      severity: 'high',
      description: `Predicted 168h (${prediction.predicted_168h.toFixed(2)}) approaches datasheet limit (${component.datasheet_limit.toFixed(2)}, margin=${prediction.predicted_margin.toFixed(2)})`,
    });
  }

  // Future drift
  const driftRatio = Math.abs(prediction.predicted_drift_96_168) / Math.max(Math.abs(component.nominal_value), CONFIG.EPSILON);
  if (driftRatio >= CONFIG.FUTURE_DRIFT.high) {
    factors.push({
      factor: 'Future Drift',
      value: `${prediction.predicted_drift_96_168.toFixed(2)}`,
      severity: 'high',
      description: `Strong predicted drift from 96h to 168h (${prediction.predicted_drift_96_168.toFixed(2)}, ${(driftRatio * 100).toFixed(1)}% of nominal)`,
    });
  } else if (driftRatio >= CONFIG.FUTURE_DRIFT.moderate) {
    factors.push({
      factor: 'Future Drift',
      value: `${prediction.predicted_drift_96_168.toFixed(2)}`,
      severity: 'moderate',
      description: `Moderate predicted drift from 96h to 168h (${prediction.predicted_drift_96_168.toFixed(2)})`,
    });
  }

  return factors;
}

function generateDecisionReason(
  decision: 'PASS' | 'MONITOR' | 'EARLY_REJECT',
  factors: RiskFactor[],
  riskScore: number
): string {
  if (decision === 'PASS') {
    if (factors.length === 0) {
      return 'The component is consistent with its lot baseline, has a low anomaly score, and its predicted 168h value remains within the acceptable datasheet limit. No significant risk factors were identified.';
    }
    return `The component shows no significant risk indicators. ${factors.map(f => f.description).join('. ')}. Overall risk remains low.`;
  }

  if (decision === 'MONITOR') {
    const reasons = factors.map(f => f.description).join('. ');
    return `The component shows moderate risk indicators (risk score: ${riskScore.toFixed(1)}/100). ${reasons}. The predicted 168h value remains within acceptable bounds, so the system recommends monitoring rather than early rejection.`;
  }

  // EARLY_REJECT
  const reasons = factors.map(f => f.description).join('. ');
  return `The component shows strong evidence of risk (risk score: ${riskScore.toFixed(1)}/100). ${reasons}. Multiple risk factors combined to trigger an early rejection recommendation before the final 168h screening point.`;
}
