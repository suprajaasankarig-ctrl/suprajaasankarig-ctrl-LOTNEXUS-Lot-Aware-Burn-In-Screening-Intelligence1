// LOTNEXUS — Shared Type Definitions

export interface RawComponent {
  component_id: string;
  lot_id: string;
  component_type: string;
  parameter_name: string;
  nominal_value: number;
  datasheet_limit: number;
  temperature: number;
  voltage: number;
  value_0h: number;
  value_24h: number;
  value_96h: number;
  value_168h: number;
  manufacturing_shift: string;
  test_date: string;
  defect_label: 'normal' | 'defective';
  failure_type: string;
}

export interface LotBaseline {
  lot_id: string;
  component_type: string;
  component_count: number;
  median: number;
  mad: number; // Mean Absolute Deviation
  q1: number;
  q3: number;
  iqr: number;
  high_risk_count: number;
}

export interface LotDeviation {
  robust_z: number;
  iqr_position: number;
  iqr_deviation: number;
  absolute_lot_deviation: number;
  relative_lot_deviation: number;
}

export interface AnomalyResult {
  statistical_score: number;
  isolation_forest_score: number;
  anomaly_score: number;
  anomaly_band: string;
  is_isolation_anomaly: boolean;
  raw_isolation_score: number;
}

export interface PredictionResult {
  predicted_168h: number;
  predicted_drift_96_168: number;
  observed_drift_0_24: number;
  observed_drift_24_96: number;
  observed_drift_0_96: number;
  predicted_margin: number;
  predicted_limit_ratio: number;
}

export interface RiskResult {
  risk_score: number;
  decision: 'PASS' | 'MONITOR' | 'EARLY_REJECT';
  decision_reason: string;
  risk_factors: RiskFactor[];
  risk_components: {
    anomaly_component: number;
    lot_deviation_component: number;
    predicted_limit_component: number;
    future_drift_component: number;
  };
}

export interface RiskFactor {
  factor: string;
  value: string;
  severity: 'low' | 'moderate' | 'high' | 'critical';
  description: string;
}

export interface ShapFeature {
  feature: string;
  actual_value: string;
  shap_contribution: number;
  direction: 'Increased Risk' | 'Reduced Risk' | 'Neutral';
  importance: number;
}

export interface ShapResult {
  base_value: number;
  model_output: number;
  features: ShapFeature[];
  natural_language: string;
}

export interface ModelMetrics {
  mae: number;
  rmse: number;
  r2: number;
  baseline_mae: number;
  baseline_rmse: number;
  baseline_r2: number;
  recall: number;
  false_negative_rate: number;
  precision: number;
  f1: number;
  rescreening_rate: number;
  total_components: number;
  pass_count: number;
  monitor_count: number;
  early_reject_count: number;
  high_risk_count: number;
  lots_analysed: number;
}

export interface ComponentAnalysis {
  component: RawComponent;
  lot_baseline: LotBaseline;
  lot_deviation: LotDeviation;
  anomaly: AnomalyResult;
  prediction: PredictionResult;
  risk: RiskResult;
  explanation: ShapResult;
  timeseries: {
    hours: number[];
    observed: (number | null)[];
    predicted_168h: number;
    datasheet_limit: number;
    nominal_value: number;
  };
}

export interface DashboardData {
  metrics: ModelMetrics;
  components: ComponentSummary[];
  lots: LotBaseline[];
  decisionDistribution: { name: string; value: number; color: string }[];
  anomalyDistribution: { name: string; value: number; color: string }[];
}

export interface ComponentSummary {
  component_id: string;
  lot_id: string;
  component_type: string;
  anomaly_score: number;
  predicted_168h: number;
  risk_score: number;
  decision: 'PASS' | 'MONITOR' | 'EARLY_REJECT';
  defect_label: string;
}
