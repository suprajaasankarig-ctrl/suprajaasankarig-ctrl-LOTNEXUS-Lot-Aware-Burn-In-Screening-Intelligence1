// LOTNEXUS — Evaluation Metrics
// Centralized regression + classification metrics.

export interface RegressionMetrics {
  mae: number;
  rmse: number;
  r2: number;
}

export interface ClassificationMetrics {
  tp: number;
  tn: number;
  fp: number;
  fn: number;
  precision: number;
  recall: number;
  f1: number;
  false_negative_rate: number;
  accuracy: number;
}

export interface ConfusionMatrix {
  tp: number;
  tn: number;
  fp: number;
  fn: number;
}

const EPSILON = 1e-9;

export function calculateRegressionMetrics(
  actual: number[],
  predicted: number[],
): RegressionMetrics {
  if (actual.length === 0 || predicted.length === 0) {
    return {
      mae: 0,
      rmse: 0,
      r2: 0,
    };
  }

  const n = Math.min(actual.length, predicted.length);

  let absoluteError = 0;
  let squaredError = 0;

  const meanActual =
    actual.slice(0, n).reduce((sum, value) => sum + value, 0) / n;

  let totalVariance = 0;

  for (let i = 0; i < n; i++) {
    const error = actual[i] - predicted[i];

    absoluteError += Math.abs(error);
    squaredError += error * error;

    const deviation = actual[i] - meanActual;
    totalVariance += deviation * deviation;
  }

  const mae = absoluteError / n;
  const rmse = Math.sqrt(squaredError / n);

  const r2 =
    totalVariance > EPSILON
      ? 1 - squaredError / totalVariance
      : 0;

  return {
    mae,
    rmse,
    r2,
  };
}

export function buildConfusionMatrix(
  actual: number[],
  predicted: number[],
): ConfusionMatrix {
  let tp = 0;
  let tn = 0;
  let fp = 0;
  let fn = 0;

  const n = Math.min(actual.length, predicted.length);

  for (let i = 0; i < n; i++) {
    const a = actual[i] ? 1 : 0;
    const p = predicted[i] ? 1 : 0;

    if (a === 1 && p === 1) {
      tp++;
    } else if (a === 0 && p === 0) {
      tn++;
    } else if (a === 0 && p === 1) {
      fp++;
    } else {
      fn++;
    }
  }

  return { tp, tn, fp, fn };
}

export function calculateClassificationMetrics(
  actual: number[],
  predicted: number[],
): ClassificationMetrics {
  const { tp, tn, fp, fn } = buildConfusionMatrix(actual, predicted);

  const precision =
    tp + fp > 0
      ? tp / (tp + fp)
      : 0;

  const recall =
    tp + fn > 0
      ? tp / (tp + fn)
      : 0;

  const f1 =
    precision + recall > 0
      ? (2 * precision * recall) /
        (precision + recall)
      : 0;

  const falseNegativeRate =
    tp + fn > 0
      ? fn / (tp + fn)
      : 0;

  const total = tp + tn + fp + fn;

  const accuracy =
    total > 0
      ? (tp + tn) / total
      : 0;

  return {
    tp,
    tn,
    fp,
    fn,
    precision,
    recall,
    f1,
    false_negative_rate: falseNegativeRate,
    accuracy,
  };
}

export function calculatePercentage(value: number): number {
  return Math.round(value * 10000) / 100;
}

export function roundMetric(
  value: number,
  decimals = 4,
): number {
  const multiplier = Math.pow(10, decimals);
  return Math.round(value * multiplier) / multiplier;
}