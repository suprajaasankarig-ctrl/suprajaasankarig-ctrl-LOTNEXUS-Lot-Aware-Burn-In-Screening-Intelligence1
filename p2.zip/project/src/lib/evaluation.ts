// LOTNEXUS — Data Validation Layer
// Validates component measurements before they enter the ML pipeline.

import type { RawComponent } from './types';

export interface ValidationIssue {
  component_id: string;
  field: string;
  message: string;
  severity: 'warning' | 'error';
}

export interface ValidationResult {
  valid: boolean;
  issues: ValidationIssue[];
  checked_components: number;
  invalid_components: number;
  warning_count: number;
  error_count: number;
}

function addIssue(
  issues: ValidationIssue[],
  componentId: string,
  field: string,
  message: string,
  severity: 'warning' | 'error',
): void {
  issues.push({
    component_id: componentId,
    field,
    message,
    severity,
  });
}

function isFiniteNumber(value: number): boolean {
  return Number.isFinite(value);
}

export function validateComponent(
  component: RawComponent,
): ValidationIssue[] {
  const issues: ValidationIssue[] = [];

  const numericFields: Array<keyof RawComponent> = [
    'nominal_value',
    'datasheet_limit',
    'temperature',
    'voltage',
    'value_0h',
    'value_24h',
    'value_96h',
    'value_168h',
  ];

  for (const field of numericFields) {
    const value = component[field];

    if (
      typeof value !== 'number' ||
      !isFiniteNumber(value)
    ) {
      addIssue(
        issues,
        component.component_id,
        String(field),
        'Measurement is missing or not a finite number.',
        'error',
      );
    }
  }

  if (!component.component_id?.trim()) {
    addIssue(
      issues,
      component.component_id || 'UNKNOWN',
      'component_id',
      'Component ID is missing.',
      'error',
    );
  }

  if (!component.lot_id?.trim()) {
    addIssue(
      issues,
      component.component_id,
      'lot_id',
      'Lot ID is missing.',
      'error',
    );
  }

  if (!component.parameter_name?.trim()) {
    addIssue(
      issues,
      component.component_id,
      'parameter_name',
      'Parameter name is missing.',
      'error',
    );
  }

  if (component.datasheet_limit <= 0) {
    addIssue(
      issues,
      component.component_id,
      'datasheet_limit',
      'Datasheet limit must be greater than zero.',
      'error',
    );
  }

  if (component.nominal_value < 0) {
    addIssue(
      issues,
      component.component_id,
      'nominal_value',
      'Nominal value cannot be negative.',
      'error',
    );
  }

  if (component.temperature < -273.15) {
    addIssue(
      issues,
      component.component_id,
      'temperature',
      'Temperature cannot be below absolute zero.',
      'error',
    );
  }

  if (component.voltage < 0) {
    addIssue(
      issues,
      component.component_id,
      'voltage',
      'Voltage cannot be negative in this prototype dataset.',
      'warning',
    );
  }

  const values = [
    component.value_0h,
    component.value_24h,
    component.value_96h,
    component.value_168h,
  ];

  if (values.some((value) => value < 0)) {
    addIssue(
      issues,
      component.component_id,
      'measurements',
      'One or more measurements are negative. Verify parameter semantics.',
      'warning',
    );
  }

  if (
    component.value_24h === component.value_0h &&
    component.value_96h === component.value_24h &&
    component.value_168h === component.value_96h
  ) {
    addIssue(
      issues,
      component.component_id,
      'measurements',
      'All burn-in measurements are identical; verify sensor/test acquisition.',
      'warning',
    );
  }

  return issues;
}

export function validateDataset(
  data: RawComponent[],
): ValidationResult {
  const issues: ValidationIssue[] = [];

  for (const component of data) {
    issues.push(...validateComponent(component));
  }

  const invalidComponentIds = new Set(
    issues
      .filter((issue) => issue.severity === 'error')
      .map((issue) => issue.component_id),
  );

  const warningCount = issues.filter(
    (issue) => issue.severity === 'warning',
  ).length;

  const errorCount = issues.filter(
    (issue) => issue.severity === 'error',
  ).length;

  return {
    valid: errorCount === 0,
    issues,
    checked_components: data.length,
    invalid_components: invalidComponentIds.size,
    warning_count: warningCount,
    error_count: errorCount,
  };
}

export function cleanDataset(
  data: RawComponent[],
): RawComponent[] {
  return data.filter((component) => {
    const issues = validateComponent(component);

    return !issues.some(
      (issue) => issue.severity === 'error',
    );
  });
}