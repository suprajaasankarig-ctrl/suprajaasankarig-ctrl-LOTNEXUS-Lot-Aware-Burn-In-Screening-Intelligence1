// LOTNEXUS — Shared UI Helpers
// Decision badges, anomaly band colors, formatting utilities.

import type { Decision, AnomalyBand } from './config';

export function getDecisionColor(decision: Decision): { bg: string; text: string; border: string; dot: string } {
  switch (decision) {
    case 'PASS':
      return { bg: 'bg-emerald-500/10', text: 'text-emerald-400', border: 'border-emerald-500/30', dot: 'bg-emerald-500' };
    case 'MONITOR':
      return { bg: 'bg-amber-500/10', text: 'text-amber-400', border: 'border-amber-500/30', dot: 'bg-amber-500' };
    case 'EARLY_REJECT':
      return { bg: 'bg-red-500/10', text: 'text-red-400', border: 'border-red-500/30', dot: 'bg-red-500' };
    default:
      return { bg: 'bg-gray-500/10', text: 'text-gray-400', border: 'border-gray-500/30', dot: 'bg-gray-500' };
  }
}

export function getAnomalyColor(band: string): { bg: string; text: string; border: string } {
  switch (band) {
    case 'Low':
      return { bg: 'bg-emerald-500/10', text: 'text-emerald-400', border: 'border-emerald-500/30' };
    case 'Moderate':
      return { bg: 'bg-amber-500/10', text: 'text-amber-400', border: 'border-amber-500/30' };
    case 'High':
      return { bg: 'bg-orange-500/10', text: 'text-orange-400', border: 'border-orange-500/30' };
    case 'Critical':
      return { bg: 'bg-red-500/10', text: 'text-red-400', border: 'border-red-500/30' };
    default:
      return { bg: 'bg-gray-500/10', text: 'text-gray-400', border: 'border-gray-500/30' };
  }
}

export function getRiskColor(score: number): string {
  if (score >= 65) return 'text-red-400';
  if (score >= 35) return 'text-amber-400';
  return 'text-emerald-400';
}

export function getRiskBarColor(score: number): string {
  if (score >= 65) return 'bg-red-500';
  if (score >= 35) return 'bg-amber-500';
  return 'bg-emerald-500';
}

export function formatNumber(v: number, decimals = 2): string {
  return v.toFixed(decimals);
}

export function formatPercent(v: number, decimals = 1): string {
  return `${(v * 100).toFixed(decimals)}%`;
}
