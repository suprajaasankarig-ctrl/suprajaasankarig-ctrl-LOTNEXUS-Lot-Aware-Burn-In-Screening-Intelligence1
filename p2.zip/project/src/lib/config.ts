// LOTNEXUS — Central Configuration
// All configurable thresholds, weights, and model parameters live here.

export const CONFIG = {
  // Anomaly score thresholds (0-100)
  ANOMALY_LOW: 30,
  ANOMALY_MODERATE: 60,
  ANOMALY_HIGH: 80,

  // Risk decision thresholds (0-100)
  MONITOR_THRESHOLD: 35,
  EARLY_REJECT_THRESHOLD: 65,

  // Isolation Forest parameters
  ISOLATION_FOREST: {
    nEstimators: 120,
    contamination: 0.12,
    maxSamples: 256,
    randomState: 42,
  },

  // XGBoost-equivalent gradient boosting parameters
  XGBOOST: {
    nEstimators: 150,
    maxDepth: 4,
    learningRate: 0.08,
    subsample: 0.85,
    colSampleByTree: 0.85,
    minChildWeight: 3,
    regLambda: 1.2,
    regAlpha: 0.1,
    randomState: 42,
  },

  // Risk engine weights (must sum to ~1.0)
  RISK_WEIGHTS: {
    anomaly: 0.30,
    lotDeviation: 0.22,
    predictedLimit: 0.28,
    futureDrift: 0.20,
  },

  // Lot deviation thresholds (robust z-score)
  LOT_DEVIATION: {
    moderate: 2.5,
    high: 4.0,
  },

  // Prediction margin thresholds (fraction of datasheet limit)
  PREDICTED_MARGIN: {
    warningRatio: 0.85, // predicted_168h > 85% of limit → risk
    violationRatio: 1.0, // predicted_168h > 100% of limit → high risk
  },

  // Drift thresholds
  FUTURE_DRIFT: {
    moderate: 0.05, // 5% of nominal value
    high: 0.10, // 10% of nominal value
  },

  // Epsilon for numerical safety
  EPSILON: 1e-9,
} as const;

// Dataset parameters
export const DATASET_CONFIG = {
  numLots: 10,
  componentsPerLot: 50,
  defectRate: 0.12,
  randomSeed: 42,
  componentTypes: ['Resistor 10kΩ', 'Capacitor 100µF', 'Op-Amp LM741', 'Diode 1N4148', 'MOSFET IRF540'],
  parameterNames: ['leakage_current', 'offset_voltage', 'breakdown_voltage', 'threshold_voltage', 'insulation_resistance'],
  temperatures: [125, 150, 175],
  voltages: [5.0, 12.0, 24.0],
  shifts: ['A', 'B', 'C'],
} as const;

// Anomaly band labels
export type AnomalyBand = 'Low' | 'Moderate' | 'High' | 'Critical';
export type Decision = 'PASS' | 'MONITOR' | 'EARLY_REJECT';
