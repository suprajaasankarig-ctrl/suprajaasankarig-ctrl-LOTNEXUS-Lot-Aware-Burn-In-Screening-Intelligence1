// LOTNEXUS — SHAP-Style Explainability
// Implements a model-agnostic feature attribution method using a perturbation-based
// approach (similar to SHAP's KernelSHAP) to explain the risk score.
//
// The explainable risk function maps four primary decision features:
//   lot_deviation, datasheet_limit, anomaly_score, predicted_168h
// into a risk score. We compute SHAP values by measuring the marginal contribution
// of each feature across all possible coalitions.

import { CONFIG } from './config';
import type {
  RawComponent,
  LotBaseline,
  LotDeviation,
  AnomalyResult,
  PredictionResult,
  RiskResult,
  ShapResult,
  ShapFeature,
} from './types';

// The explainable risk function — a deterministic mapping from 4 features to a 0-100 risk score.
// This mirrors the risk engine logic but uses only the 4 primary features so SHAP is tractable.
function explainableRiskFunction(
  lotDeviation: number, // robust z-score
  datasheetLimit: number,
  anomalyScore: number,
  predicted168h: number,
  nominalValue: number
): number {
  const absZ = Math.abs(lotDeviation);
  let lotDevComp: number;
  if (absZ >= CONFIG.LOT_DEVIATION.high) {
    lotDevComp = Math.min(100, 60 + (absZ - CONFIG.LOT_DEVIATION.high) * 8);
  } else if (absZ >= CONFIG.LOT_DEVIATION.moderate) {
    lotDevComp = 30 + ((absZ - CONFIG.LOT_DEVIATION.moderate) / (CONFIG.LOT_DEVIATION.high - CONFIG.LOT_DEVIATION.moderate)) * 30;
  } else {
    lotDevComp = (absZ / CONFIG.LOT_DEVIATION.moderate) * 30;
  }

  const limitRatio = predicted168h / Math.max(datasheetLimit, CONFIG.EPSILON);
  let limitComp: number;
  if (limitRatio >= 1.0) {
    limitComp = Math.min(100, 70 + (limitRatio - 1.0) * 150);
  } else if (limitRatio >= CONFIG.PREDICTED_MARGIN.warningRatio) {
    limitComp = 30 + ((limitRatio - CONFIG.PREDICTED_MARGIN.warningRatio) / (1.0 - CONFIG.PREDICTED_MARGIN.warningRatio)) * 40;
  } else {
    limitComp = Math.max(0, (limitRatio / CONFIG.PREDICTED_MARGIN.warningRatio) * 30);
  }

  const driftRatio = Math.abs(predicted168h - nominalValue) / Math.max(Math.abs(nominalValue), CONFIG.EPSILON);
  let driftComp: number;
  if (driftRatio >= CONFIG.FUTURE_DRIFT.high) {
    driftComp = Math.min(100, 60 + (driftRatio - CONFIG.FUTURE_DRIFT.high) * 400);
  } else if (driftRatio >= CONFIG.FUTURE_DRIFT.moderate) {
    driftComp = 30 + ((driftRatio - CONFIG.FUTURE_DRIFT.moderate) / (CONFIG.FUTURE_DRIFT.high - CONFIG.FUTURE_DRIFT.moderate)) * 30;
  } else {
    driftComp = (driftRatio / CONFIG.FUTURE_DRIFT.moderate) * 30;
  }

  const w = CONFIG.RISK_WEIGHTS;
  const risk = w.anomaly * anomalyScore + w.lotDeviation * lotDevComp + w.predictedLimit * limitComp + w.futureDrift * driftComp;
  return Math.min(100, Math.max(0, risk));
}

// --- KernelSHAP-style approximation ---
// For 4 features, we enumerate all 2^4 = 16 coalitions and compute exact Shapley values.

interface FeatureConfig {
  lotDeviation: number;
  datasheetLimit: number;
  anomalyScore: number;
  predicted168h: number;
  nominalValue: number;
}

// Background/expected values for each feature (used when feature is "absent")
function getBackgroundValues(allComponents: RawComponent[], allBaselines: LotBaseline[]): {
  lotDeviation: number;
  datasheetLimit: number;
  anomalyScore: number;
  predicted168h: number;
  nominalValue: number;
} {
  // Use median across all components as background
  const lotDevs: number[] = [];
  const limits: number[] = [];
  const anomalies: number[] = [];
  const preds: number[] = [];
  const nominals: number[] = [];

  // This is a simplified background — in practice we'd use the full training set
  for (const c of allComponents) {
    limits.push(c.datasheet_limit);
    nominals.push(c.nominal_value);
  }

  const median = (arr: number[]) => {
    const s = [...arr].sort((a, b) => a - b);
    return s[Math.floor(s.length / 2)] || 0;
  };

  return {
    lotDeviation: 0, // baseline: no deviation
    datasheetLimit: median(limits),
    anomalyScore: 15, // typical low anomaly
    predicted168h: median(nominals), // typical prediction near nominal
    nominalValue: median(nominals),
  };
}

function computeShapleyValues(
  actual: FeatureConfig,
  background: FeatureConfig
): { shap: number[]; base: number; output: number } {
  const features = ['lotDeviation', 'datasheetLimit', 'anomalyScore', 'predicted168h'] as const;
  const n = features.length;

  // Actual values
  const actualVals = [
    actual.lotDeviation,
    actual.datasheetLimit,
    actual.anomalyScore,
    actual.predicted168h,
  ];

  // Background values
  const bgVals = [
    background.lotDeviation,
    background.datasheetLimit,
    background.anomalyScore,
    background.predicted168h,
  ];

  // Base value: risk with all background features
  const baseValue = explainableRiskFunction(
    bgVals[0], bgVals[1], bgVals[2], bgVals[3], background.nominalValue
  );

  // Output value: risk with all actual features
  const outputValue = explainableRiskFunction(
    actualVals[0], actualVals[1], actualVals[2], actualVals[3], actual.nominalValue
  );

  // Exact Shapley values: for each feature i, compute marginal contribution over all coalitions
  const shap = new Array(n).fill(0);

  // Enumerate all subsets of {0,1,2,3} (2^4 = 16 subsets)
  for (let i = 0; i < n; i++) {
    let totalContribution = 0;
    let numCoalitions = 0;

    for (let mask = 0; mask < (1 << n); mask++) {
      // Only consider coalitions that do NOT include feature i
      if (mask & (1 << i)) continue;

      // Build coalition S (without i) and S∪{i}
      const coalitionS: number[] = [];
      const coalitionSWithI: number[] = [];
      for (let j = 0; j < n; j++) {
        if (mask & (1 << j)) {
          coalitionS.push(j);
        }
        if ((mask & (1 << j)) || j === i) {
          coalitionSWithI.push(j);
        }
      }

      const sizeS = coalitionS.length;

      // Weight: |S|! * (n - |S| - 1)! / n!
      const weight = factorial(sizeS) * factorial(n - sizeS - 1) / factorial(n);

      // Evaluate risk for S (features in S use actual, others use background)
      const valS = evaluateCoalition(coalitionS, actualVals, bgVals, actual, background);
      // Evaluate risk for S∪{i}
      const valSWithI = evaluateCoalition(coalitionSWithI, actualVals, bgVals, actual, background);

      totalContribution += weight * (valSWithI - valS);
      numCoalitions++;
    }

    shap[i] = totalContribution;
  }

  return { shap, base: baseValue, output: outputValue };
}

function evaluateCoalition(
  coalition: number[],
  actualVals: number[],
  bgVals: number[],
  actual: FeatureConfig,
  background: FeatureConfig
): number {
  const vals = [...bgVals];
  for (const idx of coalition) {
    vals[idx] = actualVals[idx];
  }
  // Use actual nominal if in coalition context, else background
  const nominal = coalition.includes(3) ? actual.nominalValue : background.nominalValue;
  return explainableRiskFunction(vals[0], vals[1], vals[2], vals[3], nominal);
}

function factorial(n: number): number {
  if (n <= 1) return 1;
  let r = 1;
  for (let i = 2; i <= n; i++) r *= i;
  return r;
}

// --- Main SHAP explanation function ---

export function explainRisk(
  component: RawComponent,
  deviation: LotDeviation,
  anomaly: AnomalyResult,
  prediction: PredictionResult,
  risk: RiskResult,
  allComponents: RawComponent[],
  allBaselines: LotBaseline[]
): ShapResult {
  const background = getBackgroundValues(allComponents, allBaselines);

  const actual: FeatureConfig = {
    lotDeviation: deviation.robust_z,
    datasheetLimit: component.datasheet_limit,
    anomalyScore: anomaly.anomaly_score,
    predicted168h: prediction.predicted_168h,
    nominalValue: component.nominal_value,
  };

  const { shap, base, output } = computeShapleyValues(actual, background);

  // Build feature explanations
  const featureLabels = ['Lot Deviation', 'Datasheet Limit', 'Anomaly Score', 'Predicted 168h'];
  const actualDisplay = [
    `${deviation.robust_z.toFixed(2)}σ`,
    `${component.datasheet_limit.toFixed(2)}`,
    `${anomaly.anomaly_score.toFixed(1)}/100`,
    `${prediction.predicted_168h.toFixed(2)}`,
  ];

  const features: ShapFeature[] = shap.map((shapVal, i) => {
    const absShap = Math.abs(shapVal);
    const direction: ShapFeature['direction'] =
      shapVal > 0.5 ? 'Increased Risk' :
      shapVal < -0.5 ? 'Reduced Risk' : 'Neutral';

    return {
      feature: featureLabels[i],
      actual_value: actualDisplay[i],
      shap_contribution: Math.round(shapVal * 1000) / 1000,
      direction,
      importance: Math.round(absShap * 1000) / 1000,
    };
  });

  // Sort by importance (absolute SHAP value) descending
  features.sort((a, b) => b.importance - a.importance);

  // Generate natural language explanation
  const naturalLanguage = generateNaturalLanguage(risk.decision, features);

  return {
    base_value: Math.round(base * 100) / 100,
    model_output: Math.round(output * 100) / 100,
    features,
    natural_language: naturalLanguage,
  };
}

function generateNaturalLanguage(
  decision: 'PASS' | 'MONITOR' | 'EARLY_REJECT',
  features: ShapFeature[]
): string {
  const increased = features.filter(f => f.direction === 'Increased Risk');
  const decreased = features.filter(f => f.direction === 'Reduced Risk');

  if (decision === 'EARLY_REJECT') {
    const topFactors = increased.slice(0, 3).map(f => f.feature).join(', ');
    return `Why EARLY REJECT? The component shows elevated risk driven primarily by ${topFactors}. ` +
      `These factors increased the estimated risk score and caused the component to be flagged for early rejection before the final 168h screening point.`;
  }

  if (decision === 'MONITOR') {
    const modFactors = increased.slice(0, 2).map(f => f.feature).join(', ');
    return `Why MONITOR? The component shows moderate risk indicators from ${modFactors}. ` +
      `However, the overall evidence is not strong enough to warrant early rejection. The system recommends additional monitoring.`;
  }

  // PASS
  if (decreased.length > 0) {
    const reducingFactors = decreased.slice(0, 2).map(f => f.feature).join(', ');
    return `Why PASS? The component is consistent with its lot baseline and has a low anomaly score. ` +
      `${reducingFactors} contributed to reducing the estimated risk. The predicted 168h value remains within the acceptable datasheet limit.`;
  }
  return `Why PASS? The component is consistent with its lot baseline, has a low anomaly score, and its predicted 168h value remains within the acceptable datasheet limit. No significant risk factors were identified.`;
}
