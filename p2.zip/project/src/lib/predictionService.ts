// LOTNEXUS — Gradient Boosting Regression (XGBoost-equivalent)
// Predicts value_168h from value_0h, value_24h, value_96h + derived drift features.
// Implements gradient boosting with squared error loss, regularization, and early stopping.
//
// Feature set:
//   value_0h, value_24h, value_96h, drift_0_to_24, drift_24_to_96, total_drift_0_to_96
// Target:
//   value_168h
// NEVER uses value_168h, defect_label, or failure_type as input features.

import { CONFIG } from './config';
import type { RawComponent, PredictionResult } from './types';

// --- Regression Tree (CART, max-depth limited) ---

interface TreeNode {
  isLeaf: boolean;
  feature: number;
  threshold: number;
  left: TreeNode | null;
  right: TreeNode | null;
  value: number;
}

function buildTree(
  X: number[][],
  y: number[],
  gradients: number[],
  depth: number,
  maxDepth: number,
  minChildWeight: number,
  regLambda: number
): TreeNode {
  const n = X.length;
  if (n === 0 || depth >= maxDepth) {
    const sumGrad = gradients.reduce((s, g) => s + g, 0);
    const leafValue = -sumGrad / (n + regLambda);
    return { isLeaf: true, feature: -1, threshold: 0, left: null, right: null, value: leafValue };
  }

  const numFeatures = X[0].length;
  let bestGain = -Infinity;
  let bestFeature = 0;
  let bestThreshold = 0;
  let bestLeftIdx: number[] = [];
  let bestRightIdx: number[] = [];

  for (let f = 0; f < numFeatures; f++) {
    const sortedIdx = [...Array(n).keys()].sort((a, b) => X[a][f] - X[b][f]);

    // Cumulative gradient sums for split evaluation
    let leftGradSum = 0;
    let leftCount = 0;
    const totalGradSum = gradients.reduce((s, g) => s + g, 0);
    const totalCount = n;

    for (let i = 0; i < n - 1; i++) {
      const idx = sortedIdx[i];
      leftGradSum += gradients[idx];
      leftCount++;

      // Skip if values are identical
      if (X[sortedIdx[i]][f] === X[sortedIdx[i + 1]][f]) continue;

      const rightGradSum = totalGradSum - leftGradSum;
      const rightCount = totalCount - leftCount;

      // XGBoost-style gain: 0.5 * (GL^2/(HL+λ) + GR^2/(HR+λ) - (GL+GR)^2/(HL+HR+λ))
      // For squared error, Hessian H = 1 for every sample
      const gain =
        0.5 * (
          (leftGradSum * leftGradSum) / (leftCount + regLambda) +
          (rightGradSum * rightGradSum) / (rightCount + regLambda) -
          (totalGradSum * totalGradSum) / (totalCount + regLambda)
        );

      if (gain > bestGain) {
        bestGain = gain;
        bestFeature = f;
        bestThreshold = (X[sortedIdx[i]][f] + X[sortedIdx[i + 1]][f]) / 2;
        bestLeftIdx = sortedIdx.slice(0, i + 1);
        bestRightIdx = sortedIdx.slice(i + 1);
      }
    }
  }

  // Check min_child_weight
  if (bestLeftIdx.length < minChildWeight || bestRightIdx.length < minChildWeight) {
    const sumGrad = gradients.reduce((s, g) => s + g, 0);
    const leafValue = -sumGrad / (n + regLambda);
    return { isLeaf: true, feature: -1, threshold: 0, left: null, right: null, value: leafValue };
  }

  const leftX = bestLeftIdx.map((i) => X[i]);
  const leftY = bestLeftIdx.map((i) => y[i]);
  const leftG = bestLeftIdx.map((i) => gradients[i]);
  const rightX = bestRightIdx.map((i) => X[i]);
  const rightY = bestRightIdx.map((i) => y[i]);
  const rightG = bestRightIdx.map((i) => gradients[i]);

  return {
    isLeaf: false,
    feature: bestFeature,
    threshold: bestThreshold,
    left: buildTree(leftX, leftY, leftG, depth + 1, maxDepth, minChildWeight, regLambda),
    right: buildTree(rightX, rightY, rightG, depth + 1, maxDepth, minChildWeight, regLambda),
    value: 0,
  };
}

function predictTree(node: TreeNode, x: number[]): number {
  if (node.isLeaf) return node.value;
  if (x[node.feature] < node.threshold) return predictTree(node.left!, x);
  return predictTree(node.right!, x);
}

// --- Gradient Boosting Model ---

export interface GBMModel {
  trees: TreeNode[];
  initPrediction: number;
  learningRate: number;
  nEstimators: number;
  trainMetrics: { mae: number; rmse: number; r2: number };
}

// Feature extraction
export function extractPredictionFeatures(component: RawComponent): number[] {
  const drift0to24 = component.value_24h - component.value_0h;
  const drift24to96 = component.value_96h - component.value_24h;
  const totalDrift0to96 = component.value_96h - component.value_0h;
  return [
    component.value_0h,
    component.value_24h,
    component.value_96h,
    drift0to24,
    drift24to96,
    totalDrift0to96,
  ];
}

// Train/test split (no leakage — random shuffle with fixed seed)
function mulberry32(seed: number) {
  let s = seed >>> 0;
  return function () {
    s = (s + 0x6d2b79f5) >>> 0;
    let t = s;
    t = Math.imul(t ^ (t >>> 15), t | 1);
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

export function trainTestSplit<T>(arr: T[], testRatio: number, seed: number): { train: T[]; test: T[] } {
  const rng = mulberry32(seed);
  const shuffled = [...arr];
  for (let i = shuffled.length - 1; i > 0; i--) {
    const j = Math.floor(rng() * (i + 1));
    [shuffled[i], shuffled[j]] = [shuffled[j], shuffled[i]];
  }
  const splitIdx = Math.floor(shuffled.length * (1 - testRatio));
  return { train: shuffled.slice(0, splitIdx), test: shuffled.slice(splitIdx) };
}

export function trainGBM(components: RawComponent[]): GBMModel {
  const { nEstimators, maxDepth, learningRate, minChildWeight, regLambda, regAlpha, randomState } = CONFIG.XGBOOST;

  // Split: 80% train, 20% test
  const { train, test } = trainTestSplit(components, 0.2, randomState);

  // Build feature matrix and target vector
  const X = train.map(extractPredictionFeatures);
  const y = train.map((c) => c.value_168h);

  // Initial prediction: mean of target
  const initPrediction = y.reduce((s, v) => s + v, 0) / y.length;

  // Current predictions (residuals = y - current_pred)
  let currentPreds = new Array(train.length).fill(initPrediction);

  const trees: TreeNode[] = [];
  let bestValMAE = Infinity;
  let bestTrees: TreeNode[] = [];

  for (let iter = 0; iter < nEstimators; iter++) {
    // Gradients for squared error: gradient = -(y - pred) = pred - y
    const gradients = currentPreds.map((p, i) => p - y[i]);

    // L1 regularization (Lasso): add subgradient if gradient is small
    if (regAlpha > 0) {
      for (let i = 0; i < gradients.length; i++) {
        if (Math.abs(gradients[i]) <= regAlpha) {
          gradients[i] = 0;
        } else {
          gradients[i] -= Math.sign(gradients[i]) * regAlpha;
        }
      }
    }

    // Build a tree on the gradients
    const tree = buildTree(X, y, gradients, 0, maxDepth, minChildWeight, regLambda);
    trees.push(tree);

    // Update predictions
    for (let i = 0; i < train.length; i++) {
      currentPreds[i] += learningRate * predictTree(tree, X[i]);
    }

    // Evaluate on test set for early stopping
    const testMAE = evaluateMAE(test, initPrediction, trees, learningRate);
    if (testMAE < bestValMAE) {
      bestValMAE = testMAE;
      bestTrees = [...trees];
    }
  }

  // Use best iteration (early stopping)
  const finalTrees = bestTrees.length > 0 ? bestTrees : trees;
  const finalModel: GBMModel = {
    trees: finalTrees,
    initPrediction,
    learningRate,
    nEstimators: finalTrees.length,
    trainMetrics: { mae: 0, rmse: 0, r2: 0 },
  };

  // Calculate metrics on test set
  const testX = test.map(extractPredictionFeatures);
  const testY = test.map((c) => c.value_168h);
  const testPreds = testX.map((x) => predictGBM(finalModel, x));

  finalModel.trainMetrics = calculateMetrics(testY, testPreds);

  return finalModel;
}

function evaluateMAE(
  test: RawComponent[],
  initPrediction: number,
  trees: TreeNode[],
  learningRate: number
): number {
  let totalErr = 0;
  for (const c of test) {
    const features = extractPredictionFeatures(c);
    let pred = initPrediction;
    for (const tree of trees) {
      pred += learningRate * predictTree(tree, features);
    }
    totalErr += Math.abs(pred - c.value_168h);
  }
  return totalErr / test.length;
}

export function predictGBM(model: GBMModel, features: number[]): number {
  let pred = model.initPrediction;
  for (const tree of model.trees) {
    pred += model.learningRate * predictTree(tree, features);
  }
  return Math.round(pred * 10000) / 10000;
}

export function calculateMetrics(actual: number[], predicted: number[]): { mae: number; rmse: number; r2: number } {
  const n = actual.length;
  if (n === 0) return { mae: 0, rmse: 0, r2: 0 };

  let sumAbsErr = 0;
  let sumSqErr = 0;
  const meanActual = actual.reduce((s, v) => s + v, 0) / n;
  let sumSqTotal = 0;

  for (let i = 0; i < n; i++) {
    const err = actual[i] - predicted[i];
    sumAbsErr += Math.abs(err);
    sumSqErr += err * err;
    sumSqTotal += (actual[i] - meanActual) ** 2;
  }

  const mae = sumAbsErr / n;
  const rmse = Math.sqrt(sumSqErr / n);
  const r2 = sumSqTotal > CONFIG.EPSILON ? 1 - sumSqErr / sumSqTotal : 0;

  return {
    mae: Math.round(mae * 10000) / 10000,
    rmse: Math.round(rmse * 10000) / 10000,
    r2: Math.round(r2 * 10000) / 10000,
  };
}

// --- Linear regression baseline for comparison ---
export function trainLinearRegression(components: RawComponent[]): {
  coefficients: number[];
  intercept: number;
  metrics: { mae: number; rmse: number; r2: number };
} {
  const { train, test } = trainTestSplit(components, 0.2, 99);
  const X = train.map(extractPredictionFeatures);
  const y = train.map((c) => c.value_168h);

  // Normal equation: w = (X^T X)^-1 X^T y with regularization
  const nFeatures = X[0].length;
  const nSamples = X.length;

  // Add bias column
  const Xb = X.map((row) => [1, ...row]);
  const XtX = matrixMultiply(transpose(Xb), Xb);
  // Ridge regularization
  for (let i = 0; i < XtX.length; i++) XtX[i][i] += 0.01;
  const XtXInv = matrixInverse(XtX);
  const Xty = matrixVectorMultiply(transpose(Xb), y);
  const weights = matrixVectorMultiply(XtXInv, Xty);

  const intercept = weights[0];
  const coefficients = weights.slice(1);

  // Evaluate on test set
  const testX = test.map(extractPredictionFeatures);
  const testY = test.map((c) => c.value_168h);
  const testPreds = testX.map((x) =>
    intercept + x.reduce((s, v, i) => s + coefficients[i] * v, 0)
  );

  return { coefficients, intercept, metrics: calculateMetrics(testY, testPreds) };
}

function transpose(m: number[][]): number[][] {
  return m[0].map((_, j) => m.map((row) => row[j]));
}

function matrixMultiply(a: number[][], b: number[][]): number[][] {
  const result: number[][] = [];
  for (let i = 0; i < a.length; i++) {
    result[i] = [];
    for (let j = 0; j < b[0].length; j++) {
      let sum = 0;
      for (let k = 0; k < b.length; k++) sum += a[i][k] * b[k][j];
      result[i][j] = sum;
    }
  }
  return result;
}

function matrixVectorMultiply(m: number[][], v: number[]): number[] {
  return m.map((row) => row.reduce((s, val, i) => s + val * v[i], 0));
}

function matrixInverse(m: number[][]): number[][] {
  const n = m.length;
  const aug = m.map((row, i) => [...row, ...Array(n).fill(0).map((_, j) => (i === j ? 1 : 0))]);

  for (let col = 0; col < n; col++) {
    let maxRow = col;
    for (let row = col + 1; row < n; row++) {
      if (Math.abs(aug[row][col]) > Math.abs(aug[maxRow][col])) maxRow = row;
    }
    [aug[col], aug[maxRow]] = [aug[maxRow], aug[col]];

    const pivot = aug[col][col];
    if (Math.abs(pivot) < CONFIG.EPSILON) continue;
    for (let j = 0; j < 2 * n; j++) aug[col][j] /= pivot;

    for (let row = 0; row < n; row++) {
      if (row === col) continue;
      const factor = aug[row][col];
      for (let j = 0; j < 2 * n; j++) aug[row][j] -= factor * aug[col][j];
    }
  }

  return aug.map((row) => row.slice(n));
}

// --- Full prediction for a component ---

export function predictComponent(model: GBMModel, component: RawComponent): PredictionResult {
  const features = extractPredictionFeatures(component);
  const predicted168h = predictGBM(model, features);

  const predictedDrift96to168 = Math.round((predicted168h - component.value_96h) * 10000) / 10000;
  const observedDrift0to24 = Math.round((component.value_24h - component.value_0h) * 10000) / 10000;
  const observedDrift24to96 = Math.round((component.value_96h - component.value_24h) * 10000) / 10000;
  const observedDrift0to96 = Math.round((component.value_96h - component.value_0h) * 10000) / 10000;
  const predictedMargin = Math.round((component.datasheet_limit - predicted168h) * 10000) / 10000;
  const predictedLimitRatio = Math.round((predicted168h / component.datasheet_limit) * 10000) / 10000;

  return {
    predicted_168h: predicted168h,
    predicted_drift_96_168: predictedDrift96to168,
    observed_drift_0_24: observedDrift0to24,
    observed_drift_24_96: observedDrift24to96,
    observed_drift_0_96: observedDrift0to96,
    predicted_margin: predictedMargin,
    predicted_limit_ratio: predictedLimitRatio,
  };
}
