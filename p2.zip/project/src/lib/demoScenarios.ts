// LOTNEXUS — Deterministic Demo Scenarios
// Used to demonstrate realistic burn-in situations
// without hardcoding the final risk decision.

import type { RawComponent } from './types';

export type DemoScenario =
  | 'healthy'
  | 'lot_outlier'
  | 'future_failure'
  | 'critical_failure';

export interface DemoScenarioInfo {
  id: DemoScenario;
  name: string;
  description: string;
  expectedBehaviour: string;
}

export const DEMO_SCENARIOS: DemoScenarioInfo[] = [
  {
    id: 'healthy',
    name: 'Healthy Component',
    description:
      'Stable component with normal lot-relative behaviour.',
    expectedBehaviour:
      'Low anomaly, low drift and PASS decision.',
  },
  {
    id: 'lot_outlier',
    name: 'Lot Outlier',
    description:
      'Component is within datasheet limits but deviates strongly from its manufacturing lot.',
    expectedBehaviour:
      'Elevated lot deviation and anomaly score.',
  },
  {
    id: 'future_failure',
    name: 'Future Failure',
    description:
      'Current measurement is acceptable but the predicted 168-hour value approaches or exceeds the safety limit.',
    expectedBehaviour:
      'Early warning before final screening violation.',
  },
  {
    id: 'critical_failure',
    name: 'Critical Failure',
    description:
      'Strong anomaly, abnormal lot behaviour and predicted specification violation.',
    expectedBehaviour:
      'High risk and EARLY_REJECT.',
  },
];

export function getDemoScenarioInfo(
  scenario: DemoScenario,
): DemoScenarioInfo {
  return (
    DEMO_SCENARIOS.find(
      (item) => item.id === scenario,
    ) ?? DEMO_SCENARIOS[0]
  );
}

function scoreScenario(
  component: RawComponent,
  scenario: DemoScenario,
): number {
  switch (scenario) {
    case 'healthy':
      return 0;

    case 'lot_outlier':
      return (
        Math.abs(component.value_96h) * 0.15 +
        Math.abs(
          component.value_96h -
            component.nominal_value,
        )
      );

    case 'future_failure':
      return (
        Math.abs(
          component.value_168h -
            component.datasheet_limit,
        ) +
        Math.abs(
          component.value_96h -
            component.nominal_value,
        )
      );

    case 'critical_failure':
      return (
        Math.abs(
          component.value_168h -
            component.datasheet_limit,
        ) * 2 +
        Math.abs(
          component.value_96h -
            component.nominal_value,
        ) * 1.5
      );
  }
}

export function selectDemoComponent(
  data: RawComponent[],
  scenario: DemoScenario,
): RawComponent | null {
  if (data.length === 0) {
    return null;
  }

  const sorted = [...data].sort(
    (a, b) =>
      scoreScenario(b, scenario) -
      scoreScenario(a, scenario),
  );

  if (scenario === 'healthy') {
    const healthy =
      data
        .filter(
          (component) =>
            component.defect_label === 'normal',
        )
        .sort(
          (a, b) =>
            Math.abs(
              a.value_96h -
                a.nominal_value,
            ) -
            Math.abs(
              b.value_96h -
                b.nominal_value,
            ),
        );

    return healthy[0] ?? data[0];
  }

  if (scenario === 'future_failure') {
    const candidates = data.filter(
      (component) =>
        component.value_96h <
          component.datasheet_limit &&
        component.value_168h >=
          component.datasheet_limit,
    );

    return candidates[0] ?? sorted[0];
  }

  return sorted[0];
}

export function findComponentById(
  data: RawComponent[],
  componentId: string,
): RawComponent | null {
  return (
    data.find(
      (component) =>
        component.component_id ===
        componentId,
    ) ?? null
  );
}

export function findBestEarlyWarning(
  data: RawComponent[],
): RawComponent | null {
  const candidates = data.filter(
    (component) =>
      component.value_96h <
        component.datasheet_limit &&
      component.value_168h >=
        component.datasheet_limit,
  );

  if (candidates.length === 0) {
    return null;
  }

  return candidates.sort(
    (a, b) =>
      (a.datasheet_limit - a.value_96h) -
      (b.datasheet_limit - b.value_96h),
  )[0];
}