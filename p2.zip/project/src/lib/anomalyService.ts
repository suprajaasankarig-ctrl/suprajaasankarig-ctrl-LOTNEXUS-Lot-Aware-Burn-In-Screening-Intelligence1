// LOTNEXUS — Statistical Anomaly Detection + Combined Anomaly Score
// Combines lot-relative statistical evidence (robust z-score, IQR position) with
// Isolation Forest evidence into a transparent 0-100 anomaly score.

import { CONFIG } from './config';
import type { RawComponent, LotBaseline, LotDeviation, AnomalyResult } from './types';
import type { IsolationForestResult } from './isolationForest';

// --- Statistical anomaly score ---
// Maps the robust z-score and IQR deviation to a 0-100 score.
// Uses a sigmoid-like mapping so moderate deviations don't dominate.

export function statisticalAnomalyScore(deviation: LotDeviation): number {
  const absZ = Math.abs(deviation.robust_z);
  const absIqrDev = Math.abs(deviation.iqr_deviation);

  // Robust z-score component (primary)
  // z=0 → 0, z=2.5 → ~50, z=4 → ~70, z=6+ → ~90+
  const zComponent = 100 * (1 - Math.exp(-absZ * 0.35));

  // IQR deviation component (secondary, reinforces)
  // Beyond 1.5 IQR from Q1/Q3 is the standard outlier fence
  const iqrComponent = Math.min(100, Math.max(0, (absIqrDev - 1.5) / 3.0) * 100);

  // Weighted blend: 65% z-score, 35% IQR
  const blended = 0.65 * zComponent + 0.35 * iqrComponent;

  return Math.round(Math.max(0, Math.min(100, blended)) * 100) / 100;
}

// --- Combined final anomaly score ---

export function calculateAnomalyResult(
  component: RawComponent,
  deviation: LotDeviation,
  ifResult: IsolationForestResult
): AnomalyResult {
  const statScore = statisticalAnomalyScore(deviation);
  const ifScore = ifResult.scores.get(component.component_id)?.anomaly_score_0_100 ?? 0;
  const isAnomaly = ifResult.scores.get(component.component_id)?.is_anomaly ?? false;
  const rawIfScore = ifResult.scores.get(component.component_id)?.raw_score ?? 0;

  // Combine: 45% statistical + 55% isolation forest
  // The IF captures multivariate patterns the univariate stats miss, so it gets slightly more weight.
  const combined = 0.45 * statScore + 0.55 * ifScore;
  const anomalyScore = Math.round(Math.max(0, Math.min(100, combined)) * 100) / 100;

  const band = getAnomalyBand(anomalyScore);

  return {
    statistical_score: statScore,
    isolation_forest_score: ifScore,
    anomaly_score: anomalyScore,
    anomaly_band: band,
    is_isolation_anomaly: isAnomaly,
    raw_isolation_score: rawIfScore,
  };
}

export function getAnomalyBand(score: number): string {
  if (score <= CONFIG.ANOMALY_LOW) return 'Low';
  if (score <= CONFIG.ANOMALY_MODERATE) return 'Moderate';
  if (score <= CONFIG.ANOMALY_HIGH) return 'High';
  return 'Critical';
}

export function getAnomalyBandColor(band: string): string {
  switch (band) {
    case 'Low': return '#10b981';
    case 'Moderate': return '#f59e0b';
    case 'High': return '#f97316';
    case 'Critical': return '#ef4444';
    default: return '#6b7280';
  }
}
