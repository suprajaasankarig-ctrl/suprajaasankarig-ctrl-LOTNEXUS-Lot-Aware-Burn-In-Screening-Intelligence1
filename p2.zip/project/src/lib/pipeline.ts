// LOTNEXUS — Analysis Pipeline
// Orchestrates the full pipeline:
// data → lot baselines → Module A (anomaly) → Module B (prediction)
// → Risk Engine → SHAP explanation → time-series → complete analysis.
//
// Also handles seeding the Supabase database with synthetic data
// and computed results.

import { CONFIG } from './config';
import { generateSyntheticData } from './dataGenerator';
import {
  calculateAllLotBaselines,
  calculateLotDeviation,
} from './statistics';
import { trainAndScoreIsolationForest } from './isolationForest';
import { calculateAnomalyResult } from './anomalyService';
import {
  trainGBM,
  predictComponent,
  trainLinearRegression,
  type GBMModel,
} from './predictionService';
import { calculateRisk } from './riskEngine';
import { explainRisk } from './shapService';
import { supabase } from './supabase';

import type {
  RawComponent,
  LotBaseline,
  ComponentAnalysis,
  ComponentSummary,
  ModelMetrics,
  DashboardData,
} from './types';

// -----------------------------------------------------------------------------
// IN-MEMORY CACHE
// -----------------------------------------------------------------------------

let cachedData: RawComponent[] | null = null;
let cachedBaselines: LotBaseline[] | null = null;
let cachedIFResult:
  | ReturnType<typeof trainAndScoreIsolationForest>
  | null = null;
let cachedGBMModel: GBMModel | null = null;
let cachedLinearModel:
  | ReturnType<typeof trainLinearRegression>
  | null = null;
let cachedAnalyses: Map<string, ComponentAnalysis> | null = null;
let cachedMetrics: ModelMetrics | null = null;

// -----------------------------------------------------------------------------
// TRAIN MODELS AND COMPUTE ANALYSIS
// -----------------------------------------------------------------------------

async function ensureModelsTrained(): Promise<void> {
  if (
    cachedData &&
    cachedBaselines &&
    cachedIFResult &&
    cachedGBMModel &&
    cachedLinearModel &&
    cachedAnalyses &&
    cachedMetrics
  ) {
    return;
  }

  // 1. Generate synthetic burn-in data
  const data = generateSyntheticData();
  cachedData = data;

  // 2. Calculate lot-aware baselines
  const baselines = calculateAllLotBaselines(data);
  cachedBaselines = baselines;

  // 3. Train and score Isolation Forest
  const ifResult = trainAndScoreIsolationForest(
    data,
    baselines
  );
  cachedIFResult = ifResult;

  // 4. Train GBM prediction model
  const gbmModel = trainGBM(data);
  cachedGBMModel = gbmModel;

  // 5. Train linear regression baseline
  const linearModel = trainLinearRegression(data);
  cachedLinearModel = linearModel;

  // 6. Compute component-level analysis
  const analyses = new Map<string, ComponentAnalysis>();

  for (const component of data) {
    const baseline = baselines.find(
      (b) => b.lot_id === component.lot_id
    );

    if (!baseline) {
      continue;
    }

    // Lot-relative deviation
    const deviation = calculateLotDeviation(
      component,
      baseline
    );

    // Hybrid anomaly detection
    const anomaly = calculateAnomalyResult(
      component,
      deviation,
      ifResult
    );

    // Predict 168h value
    const prediction = predictComponent(
      gbmModel,
      component
    );

    // Risk engine
    const risk = calculateRisk(
      component,
      baseline,
      deviation,
      anomaly,
      prediction
    );

    // SHAP-style explanation
    const explanation = explainRisk(
      component,
      deviation,
      anomaly,
      prediction,
      risk,
      data,
      baselines
    );

    analyses.set(component.component_id, {
      component,
      lot_baseline: baseline,
      lot_deviation: deviation,
      anomaly,
      prediction,
      risk,
      explanation,
      timeseries: {
        hours: [0, 24, 96, 168],
        observed: [
          component.value_0h,
          component.value_24h,
          component.value_96h,
          null,
        ],
        predicted_168h: prediction.predicted_168h,
        datasheet_limit: component.datasheet_limit,
        nominal_value: component.nominal_value,
      },
    });
  }

  cachedAnalyses = analyses;

  // 7. Update high-risk count for every lot
  for (const baseline of baselines) {
    let highRisk = 0;

    for (const component of data) {
      if (component.lot_id !== baseline.lot_id) {
        continue;
      }

      const analysis = analyses.get(
        component.component_id
      );

      if (
        analysis &&
        analysis.risk.decision !== 'PASS'
      ) {
        highRisk++;
      }
    }

    baseline.high_risk_count = highRisk;
  }

  // 8. Calculate metrics
  cachedMetrics = computeMetrics(
    data,
    analyses,
    gbmModel,
    linearModel
  );
}

// -----------------------------------------------------------------------------
// COMPUTE MODEL METRICS
// -----------------------------------------------------------------------------

function computeMetrics(
  data: RawComponent[],
  analyses: Map<string, ComponentAnalysis>,
  gbmModel: GBMModel,
  linearModel: ReturnType<typeof trainLinearRegression>
): ModelMetrics {
  // ---------------------------------------------------------------------------
  // REGRESSION METRICS
  // ---------------------------------------------------------------------------

  const gbmMetrics = gbmModel.trainMetrics;
  const linearMetrics = linearModel.metrics;

  // ---------------------------------------------------------------------------
  // CLASSIFICATION LABELS
  // ---------------------------------------------------------------------------
  //
  // Ground truth:
  // defective = 1
  // healthy   = 0
  //
  // Predicted:
  // PASS         = 0
  // MONITOR      = 1
  // EARLY_REJECT = 1
  // ---------------------------------------------------------------------------

  const actualLabels = data.map((component) =>
    component.defect_label === 'defective' ? 1 : 0
  );

  const predictedLabels = data.map((component) => {
    const analysis = analyses.get(
      component.component_id
    );

    if (!analysis) {
      return 0;
    }

    return analysis.risk.decision !== 'PASS'
      ? 1
      : 0;
  });

  // ---------------------------------------------------------------------------
  // CONFUSION MATRIX
  // ---------------------------------------------------------------------------

  let tp = 0;
  let fp = 0;
  let fn = 0;
  let tn = 0;

  for (let i = 0; i < actualLabels.length; i++) {
    const actual = actualLabels[i];
    const predicted = predictedLabels[i];

    if (actual === 1 && predicted === 1) {
      tp++;
    } else if (actual === 0 && predicted === 1) {
      fp++;
    } else if (actual === 1 && predicted === 0) {
      fn++;
    } else {
      tn++;
    }
  }

  // ---------------------------------------------------------------------------
  // CLASSIFICATION METRICS
  // ---------------------------------------------------------------------------

  // Recall = TP / (TP + FN)
  const recall =
    tp + fn > 0
      ? tp / (tp + fn)
      : 0;

  // False Negative Rate = FN / (TP + FN)
  const falseNegativeRate =
    tp + fn > 0
      ? fn / (tp + fn)
      : 0;

  // Precision = TP / (TP + FP)
  const precision =
    tp + fp > 0
      ? tp / (tp + fp)
      : 0;

  // F1 = 2 × Precision × Recall / (Precision + Recall)
  const f1 =
    precision + recall > 0
      ? (2 * precision * recall) /
        (precision + recall)
      : 0;

  // Accuracy is calculated for validation/debugging even though
  // the existing ModelMetrics interface does not expose it.
  const total = tp + fp + fn + tn;
  const accuracy =
    total > 0
      ? (tp + tn) / total
      : 0;

  // Prevent unused-variable compiler warnings while retaining
  // the calculation for future dashboard use.
  void accuracy;

  // ---------------------------------------------------------------------------
  // DECISION DISTRIBUTION
  // ---------------------------------------------------------------------------

  let passCount = 0;
  let monitorCount = 0;
  let earlyRejectCount = 0;
  let highRiskCount = 0;

  for (const analysis of analyses.values()) {
    if (analysis.risk.decision === 'PASS') {
      passCount++;
    } else if (
      analysis.risk.decision === 'MONITOR'
    ) {
      monitorCount++;
    } else if (
      analysis.risk.decision === 'EARLY_REJECT'
    ) {
      earlyRejectCount++;
    }

    if (
      analysis.risk.risk_score >=
      CONFIG.EARLY_REJECT_THRESHOLD
    ) {
      highRiskCount++;
    }
  }

  // MONITOR components are considered candidates
  // for additional screening/rescreening.
  const rescreeningRate =
    data.length > 0
      ? monitorCount / data.length
      : 0;

  // ---------------------------------------------------------------------------
  // RETURN METRICS
  // ---------------------------------------------------------------------------

  return {
    mae: gbmMetrics.mae,
    rmse: gbmMetrics.rmse,
    r2: gbmMetrics.r2,

    baseline_mae: linearMetrics.mae,
    baseline_rmse: linearMetrics.rmse,
    baseline_r2: linearMetrics.r2,

    recall:
      Math.round(recall * 10000) / 10000,

    false_negative_rate:
      Math.round(falseNegativeRate * 10000) /
      10000,

    precision:
      Math.round(precision * 10000) / 10000,

    f1:
      Math.round(f1 * 10000) / 10000,

    rescreening_rate:
      Math.round(rescreeningRate * 10000) /
      10000,

    total_components: data.length,

    pass_count: passCount,

    monitor_count: monitorCount,

    early_reject_count: earlyRejectCount,

    high_risk_count: highRiskCount,

    lots_analysed: new Set(
      data.map((component) => component.lot_id)
    ).size,
  };
}

// -----------------------------------------------------------------------------
// PUBLIC API — DASHBOARD DATA
// -----------------------------------------------------------------------------

export async function getDashboardData(): Promise<DashboardData> {
  await ensureModelsTrained();

  const data = cachedData!;
  const baselines = cachedBaselines!;
  const analyses = cachedAnalyses!;
  const metrics = cachedMetrics!;

  // Component summaries
  const components: ComponentSummary[] = data
    .map((component) => {
      const analysis = analyses.get(
        component.component_id
      );

      if (!analysis) {
        return null;
      }

      return {
        component_id: component.component_id,
        lot_id: component.lot_id,
        component_type:
          component.component_type,
        anomaly_score:
          analysis.anomaly.anomaly_score,
        predicted_168h:
          analysis.prediction.predicted_168h,
        risk_score:
          analysis.risk.risk_score,
        decision:
          analysis.risk.decision,
        defect_label:
          component.defect_label === 'defective'
            ? 'defective'
            : 'normal',
      };
    })
    .filter(
      (item): item is ComponentSummary =>
        item !== null
    );

  // Decision distribution
  const decisionDistribution = [
    {
      name: 'PASS',
      value: metrics.pass_count,
      color: '#10b981',
    },
    {
      name: 'MONITOR',
      value: metrics.monitor_count,
      color: '#f59e0b',
    },
    {
      name: 'EARLY REJECT',
      value: metrics.early_reject_count,
      color: '#ef4444',
    },
  ];

  // Anomaly distribution
  let low = 0;
  let moderate = 0;
  let high = 0;
  let critical = 0;

  for (const analysis of analyses.values()) {
    switch (analysis.anomaly.anomaly_band) {
      case 'Low':
        low++;
        break;

      case 'Moderate':
        moderate++;
        break;

      case 'High':
        high++;
        break;

      case 'Critical':
        critical++;
        break;
    }
  }

  const anomalyDistribution = [
    {
      name: 'Low',
      value: low,
      color: '#10b981',
    },
    {
      name: 'Moderate',
      value: moderate,
      color: '#f59e0b',
    },
    {
      name: 'High',
      value: high,
      color: '#f97316',
    },
    {
      name: 'Critical',
      value: critical,
      color: '#ef4444',
    },
  ];

  return {
    metrics,
    components,
    lots: baselines,
    decisionDistribution,
    anomalyDistribution,
  };
}

// -----------------------------------------------------------------------------
// PUBLIC API — SINGLE COMPONENT
// -----------------------------------------------------------------------------

export async function getComponentAnalysis(
  componentId: string
): Promise<ComponentAnalysis | null> {
  await ensureModelsTrained();

  return (
    cachedAnalyses!.get(componentId) ??
    null
  );
}

// -----------------------------------------------------------------------------
// PUBLIC API — ALL COMPONENTS
// -----------------------------------------------------------------------------

export async function getAllComponents(): Promise<
  ComponentSummary[]
> {
  await ensureModelsTrained();

  const data = cachedData!;
  const analyses = cachedAnalyses!;

   return data
     .map((component) => {
      const analysis = analyses.get(
        component.component_id
      );

      if (!analysis) {
        return null;
      }

      return {
        component_id: component.component_id,
        lot_id: component.lot_id,
        component_type:
          component.component_type,
        anomaly_score:
          analysis.anomaly.anomaly_score,
        predicted_168h:
          analysis.prediction.predicted_168h,
        risk_score:
          analysis.risk.risk_score,
        decision:
          analysis.risk.decision,
        defect_label:
          component.defect_label as ComponentSummary['defect_label'],
      };
    })
     .filter((item): item is NonNullable<typeof item> => item !== null);
}

// -----------------------------------------------------------------------------
// PUBLIC API — LOT BASELINES
// -----------------------------------------------------------------------------

export async function getLotBaselines(): Promise<
  LotBaseline[]
> {
  await ensureModelsTrained();

  return cachedBaselines!;
}

// -----------------------------------------------------------------------------
// PUBLIC API — SINGLE LOT
// -----------------------------------------------------------------------------

export async function getLotBaseline(
  lotId: string
): Promise<LotBaseline | null> {
  await ensureModelsTrained();

  return (
    cachedBaselines!.find(
      (baseline) =>
        baseline.lot_id === lotId
    ) ?? null
  );
}

// -----------------------------------------------------------------------------
// PUBLIC API — METRICS
// -----------------------------------------------------------------------------

export async function getMetrics(): Promise<ModelMetrics> {
  await ensureModelsTrained();

  return cachedMetrics!;
}

// -----------------------------------------------------------------------------
// PUBLIC API — SEARCH COMPONENTS
// -----------------------------------------------------------------------------

export async function searchComponents(
  query: string,
  filters: {
    lotId?: string;
    componentType?: string;
    decision?: string;
  } = {}
): Promise<ComponentSummary[]> {
  await ensureModelsTrained();

  const all = await getAllComponents();

  let results = all;

  if (query) {
    const q = query.toLowerCase();

    results = results.filter((component) =>
      component.component_id
        .toLowerCase()
        .includes(q)
    );
  }

  if (filters.lotId) {
    results = results.filter(
      (component) =>
        component.lot_id === filters.lotId
    );
  }

  if (filters.componentType) {
    results = results.filter(
      (component) =>
        component.component_type ===
        filters.componentType
    );
  }

  if (filters.decision) {
    results = results.filter(
      (component) =>
        component.decision ===
        filters.decision
    );
  }

  return results;
}

// -----------------------------------------------------------------------------
// DATABASE SEEDING
// -----------------------------------------------------------------------------

export async function seedDatabase(): Promise<{
  success: boolean;
  message: string;
}> {
  await ensureModelsTrained();

  const data = cachedData!;
  const baselines = cachedBaselines!;
  const analyses = cachedAnalyses!;

  try {
    // Clear existing data
    const { error: riskDeleteError } =
      await supabase
        .from('risk_assessments')
        .delete()
        .neq(
          'id',
          '00000000-0000-0000-0000-000000000000'
        );

    if (riskDeleteError) {
      throw riskDeleteError;
    }

    const { error: predictionDeleteError } =
      await supabase
        .from('predictions')
        .delete()
        .neq(
          'id',
          '00000000-0000-0000-0000-000000000000'
        );

    if (predictionDeleteError) {
      throw predictionDeleteError;
    }

    const { error: componentDeleteError } =
      await supabase
        .from('components')
        .delete()
        .neq(
          'id',
          '00000000-0000-0000-0000-000000000000'
        );

    if (componentDeleteError) {
      throw componentDeleteError;
    }

    const { error: lotDeleteError } =
      await supabase
        .from('lots')
        .delete()
        .neq('lot_id', '__none__');

    if (lotDeleteError) {
      throw lotDeleteError;
    }

    // -------------------------------------------------------------------------
    // INSERT LOTS
    // -------------------------------------------------------------------------

    const lotRows = baselines.map((baseline) => ({
      lot_id: baseline.lot_id,
      component_type:
        baseline.component_type,
      component_count:
        baseline.component_count,
      median: baseline.median,
      mad: baseline.mad,
      q1: baseline.q1,
      q3: baseline.q3,
      iqr: baseline.iqr,
      high_risk_count:
        baseline.high_risk_count,
    }));

    const { error: lotError } =
      await supabase
        .from('lots')
        .insert(lotRows);

    if (lotError) {
      throw lotError;
    }

    // -------------------------------------------------------------------------
    // INSERT COMPONENTS
    // -------------------------------------------------------------------------

    const componentRows = data.map(
      (component) => ({
        component_id:
          component.component_id,
        lot_id:
          component.lot_id,
        component_type:
          component.component_type,
        parameter_name:
          component.parameter_name,
        nominal_value:
          component.nominal_value,
        datasheet_limit:
          component.datasheet_limit,
        temperature:
          component.temperature,
        voltage:
          component.voltage,
        value_0h:
          component.value_0h,
        value_24h:
          component.value_24h,
        value_96h:
          component.value_96h,
        value_168h:
          component.value_168h,
        manufacturing_shift:
          component.manufacturing_shift,
        test_date:
          component.test_date,
        defect_label:
          component.defect_label,
        failure_type:
          component.failure_type,
      })
    );

    const { error: componentError } =
      await supabase
        .from('components')
        .insert(componentRows);

    if (componentError) {
      throw componentError;
    }

    // -------------------------------------------------------------------------
    // INSERT PREDICTIONS
    // -------------------------------------------------------------------------

    const predictionRows = data
      .map((component) => {
        const analysis =
          analyses.get(
            component.component_id
          );

        if (!analysis) {
          return null;
        }

        return {
          component_id:
            component.component_id,
          predicted_168h:
            analysis.prediction
              .predicted_168h,
          predicted_drift_96_168:
            analysis.prediction
              .predicted_drift_96_168,
          predicted_margin:
            analysis.prediction
              .predicted_margin,
          predicted_limit_ratio:
            analysis.prediction
              .predicted_limit_ratio,
        };
      })
      .filter(
        (
          row
        ): row is NonNullable<typeof row> =>
          row !== null
      );

    const { error: predictionError } =
      await supabase
        .from('predictions')
        .insert(predictionRows);

    if (predictionError) {
      throw predictionError;
    }

    // -------------------------------------------------------------------------
    // INSERT RISK ASSESSMENTS
    // -------------------------------------------------------------------------

    const riskRows = data
      .map((component) => {
        const analysis =
          analyses.get(
            component.component_id
          );

        if (!analysis) {
          return null;
        }

        return {
          component_id:
            component.component_id,

          statistical_score:
            analysis.anomaly
              .statistical_score,

          isolation_forest_score:
            analysis.anomaly
              .isolation_forest_score,

          anomaly_score:
            analysis.anomaly
              .anomaly_score,

          lot_deviation:
            analysis.lot_deviation
              .robust_z,

          risk_score:
            analysis.risk
              .risk_score,

          decision:
            analysis.risk
              .decision,

          decision_reason:
            analysis.risk
              .decision_reason,

          risk_factors:
            JSON.stringify(
              analysis.risk
                .risk_factors
            ),

          shap_values:
            JSON.stringify(
              analysis.explanation
                .features
            ),
        };
      })
      .filter(
        (
          row
        ): row is NonNullable<typeof row> =>
          row !== null
      );

    const { error: riskError } =
      await supabase
        .from('risk_assessments')
        .insert(riskRows);

    if (riskError) {
      throw riskError;
    }

    return {
      success: true,
      message:
        `Seeded ${data.length} components, ` +
        `${baselines.length} lots with ` +
        `predictions and risk assessments.`,
    };
  } catch (error) {
    const message =
      error instanceof Error
        ? error.message
        : String(error);

    return {
      success: false,
      message:
        `Database seed failed: ${message}`,
    };
  }
}