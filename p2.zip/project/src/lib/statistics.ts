// LOTNEXUS — Lot-Specific Baseline Engine
// Calculates median, Mean Absolute Deviation, Q1, Q3, IQR independently for each lot.
// NEVER uses global statistics — each lot's baseline is computed from only its own components.

import { CONFIG } from './config';
import type { RawComponent, LotBaseline, LotDeviation } from './types';

// --- Core statistics ---

export function median(values: number[]): number {
  if (values.length === 0) return 0;
  const sorted = [...values].sort((a, b) => a - b);
  const mid = Math.floor(sorted.length / 2);
  return sorted.length % 2 === 0
    ? (sorted[mid - 1] + sorted[mid]) / 2
    : sorted[mid];
}

// Mean Absolute Deviation: MAD = mean(|x - mean(x)|)
// As specified in the problem statement, this is Mean Absolute Deviation (not Median Absolute Deviation)
export function meanAbsoluteDeviation(values: number[]): number {
  if (values.length === 0) return 0;
  const mean = values.reduce((s, v) => s + v, 0) / values.length;
  return values.reduce((s, v) => s + Math.abs(v - mean), 0) / values.length;
}

export function quantile(sorted: number[], q: number): number {
  if (sorted.length === 0) return 0;
  const pos = (sorted.length - 1) * q;
  const base = Math.floor(pos);
  const rest = pos - base;
  if (sorted[base + 1] !== undefined) {
    return sorted[base] + rest * (sorted[base + 1] - sorted[base]);
  }
  return sorted[base];
}

export function interquartileRange(values: number[]): { q1: number; q3: number; iqr: number } {
  if (values.length === 0) return { q1: 0, q3: 0, iqr: 0 };
  const sorted = [...values].sort((a, b) => a - b);
  const q1 = quantile(sorted, 0.25);
  const q3 = quantile(sorted, 0.75);
  return { q1, q3, iqr: q3 - q1 };
}

// --- Lot baseline calculation ---

export function calculateLotBaseline(
  lotId: string,
  components: RawComponent[],
  referenceField: keyof RawComponent = 'value_96h'
): LotBaseline {
  const lotComponents = components.filter((c) => c.lot_id === lotId);
  const values = lotComponents.map((c) => c[referenceField] as number);

  const med = median(values);
  const mad = meanAbsoluteDeviation(values);
  const { q1, q3, iqr } = interquartileRange(values);

  return {
    lot_id: lotId,
    component_type: lotComponents[0]?.component_type ?? 'unknown',
    component_count: lotComponents.length,
    median: round4(med),
    mad: round4(mad),
    q1: round4(q1),
    q3: round4(q3),
    iqr: round4(iqr),
    high_risk_count: 0, // populated later by risk engine
  };
}

export function calculateAllLotBaselines(components: RawComponent[]): LotBaseline[] {
  const lotIds = [...new Set(components.map((c) => c.lot_id))].sort();
  return lotIds.map((id) => calculateLotBaseline(id, components));
}

// --- Lot deviation for a single component ---

export function calculateLotDeviation(
  component: RawComponent,
  baseline: LotBaseline
): LotDeviation {
  const value = component.value_96h;
  const mad = baseline.mad;
  const iqr = baseline.iqr;

  // Robust z-score using Mean Absolute Deviation
  // Fallback: if MAD is ~0, use IQR/1.349 (since IQR ≈ 1.349 * MAD for normal data)
  // If IQR is also ~0, use epsilon
  const safeMAD = mad > CONFIG.EPSILON * 100
    ? mad
    : iqr > CONFIG.EPSILON * 100
      ? iqr / 1.349
      : CONFIG.EPSILON;

  const robustZ = (value - baseline.median) / (safeMAD + CONFIG.EPSILON);

  // IQR-based position: how many IQRs from the median
  const safeIQR = iqr > CONFIG.EPSILON * 100 ? iqr : CONFIG.EPSILON;
  const iqrDeviation = (value - baseline.median) / safeIQR;

  // Position within IQR: (value - Q1) / IQR, where 0 = at Q1, 1 = at Q3
  const iqrPosition = (value - baseline.q1) / safeIQR;

  const absoluteLotDeviation = Math.abs(value - baseline.median);
  const relativeLotDeviation = baseline.median > CONFIG.EPSILON
    ? absoluteLotDeviation / Math.abs(baseline.median)
    : 0;

  return {
    robust_z: round4(robustZ),
    iqr_position: round4(iqrPosition),
    iqr_deviation: round4(iqrDeviation),
    absolute_lot_deviation: round4(absoluteLotDeviation),
    relative_lot_deviation: round4(relativeLotDeviation),
  };
}

function round4(v: number): number {
  return Math.round(v * 10000) / 10000;
}
