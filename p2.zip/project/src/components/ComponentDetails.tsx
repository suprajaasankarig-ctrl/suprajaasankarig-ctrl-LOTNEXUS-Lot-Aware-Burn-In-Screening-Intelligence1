// LOTNEXUS — Component Details View
// Full analysis page: header, decision banner, risk score, measurements, time-series graph,
// lot baseline, anomaly analysis, prediction analysis, SHAP explanation, decision reason.

import { useEffect, useState } from 'react';
import { ArrowLeft, AlertTriangle, ShieldCheck, Eye, TrendingUp, Activity, Cpu } from 'lucide-react';
import { getComponentAnalysis } from '@/lib/pipeline';
import type { ComponentAnalysis } from '@/lib/types';
import { TimeSeriesChart } from './TimeSeriesChart';
import { getDecisionColor, getAnomalyColor, getRiskColor, getRiskBarColor, formatNumber } from '@/lib/uiHelpers';

interface Props {
  componentId: string;
  onBack: () => void;
}

export function ComponentDetails({ componentId, onBack }: Props) {
  const [analysis, setAnalysis] = useState<ComponentAnalysis | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    setLoading(true);
    setError(null);
    getComponentAnalysis(componentId).then((a) => {
      if (a) setAnalysis(a);
      else setError(`Component ${componentId} not found`);
      setLoading(false);
    });
  }, [componentId]);

  if (loading) {
    return (
      <div className="flex items-center justify-center py-20">
        <div className="text-slate-400">Analyzing component {componentId}...</div>
      </div>
    );
  }

  if (error || !analysis) {
    return (
      <div className="flex flex-col items-center justify-center py-20 gap-4">
        <AlertTriangle className="w-10 h-10 text-amber-400" />
        <p className="text-slate-300">{error || 'Component not found'}</p>
        <button onClick={onBack} className="text-blue-400 hover:text-blue-300">Back to Dashboard</button>
      </div>
    );
  }

  const { component, lot_baseline, lot_deviation, anomaly, prediction, risk, explanation } = analysis;
  const decisionColors = getDecisionColor(risk.decision);
  const anomalyColors = getAnomalyColor(anomaly.anomaly_band);
  const DecisionIcon = risk.decision === 'PASS' ? ShieldCheck : risk.decision === 'MONITOR' ? Eye : AlertTriangle;

  return (
    <div className="space-y-6">
      {/* Back button */}
      <button onClick={onBack} className="flex items-center gap-2 text-slate-400 hover:text-white transition-colors text-sm">
        <ArrowLeft className="w-4 h-4" /> Back to Dashboard
      </button>

      {/* Component Header */}
      <div className="bg-slate-800/50 border border-slate-700/50 rounded-xl p-5">
        <div className="flex flex-wrap items-center justify-between gap-4">
          <div>
            <h1 className="text-2xl font-bold text-white flex items-center gap-3">
              <Cpu className="w-7 h-7 text-blue-400" />
              {component.component_id}
            </h1>
            <div className="flex flex-wrap gap-4 mt-2 text-sm text-slate-400">
              <span>Lot: <span className="text-slate-200 font-mono">{component.lot_id}</span></span>
              <span>Type: <span className="text-slate-200">{component.component_type}</span></span>
              <span>Parameter: <span className="text-slate-200">{component.parameter_name}</span></span>
              <span>Temp: <span className="text-slate-200">{component.temperature}°C</span></span>
              <span>Voltage: <span className="text-slate-200">{component.voltage}V</span></span>
            </div>
          </div>
        </div>
      </div>

      {/* Decision Banner */}
      <div className={`rounded-xl border ${decisionColors.border} ${decisionColors.bg} p-5`}>
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-4">
            <DecisionIcon className={`w-10 h-10 ${decisionColors.text}`} />
            <div>
              <p className="text-xs uppercase tracking-wider text-slate-400 mb-1">Final Decision</p>
              <p className={`text-2xl font-bold ${decisionColors.text}`}>{risk.decision.replace('_', ' ')}</p>
            </div>
          </div>
          <div className="text-right">
            <p className="text-xs uppercase tracking-wider text-slate-400 mb-1">Risk Score</p>
            <p className={`text-3xl font-bold ${getRiskColor(risk.risk_score)}`}>{risk.risk_score.toFixed(1)}<span className="text-lg text-slate-500">/100</span></p>
          </div>
        </div>
        {/* Risk bar */}
        <div className="mt-4">
          <div className="h-2 bg-slate-700/50 rounded-full overflow-hidden">
            <div className={`h-full ${getRiskBarColor(risk.risk_score)} rounded-full transition-all duration-500`} style={{ width: `${risk.risk_score}%` }} />
          </div>
          <div className="flex justify-between mt-1 text-xs text-slate-500">
            <span>0 (Safe)</span>
            <span>35 (Monitor)</span>
            <span>65 (Reject)</span>
            <span>100</span>
          </div>
        </div>
      </div>

      {/* Measurements + Predicted 168h */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <MeasurementCard label="0h Value" value={formatNumber(component.value_0h)} />
        <MeasurementCard label="24h Value" value={formatNumber(component.value_24h)} />
        <MeasurementCard label="96h Value" value={formatNumber(component.value_96h)} />
        <MeasurementCard label="Predicted 168h" value={formatNumber(prediction.predicted_168h)} highlight />
      </div>

      {/* Time-Series Graph */}
      <SectionCard title="Burn-In Trajectory" icon={<TrendingUp className="w-5 h-5 text-blue-400" />}>
        <TimeSeriesChart analysis={analysis} />
      </SectionCard>

      {/* Lot Baseline */}
      <SectionCard title={`${component.lot_id} Baseline — Lot-Aware Statistics`} icon={<Activity className="w-5 h-5 text-blue-400" />}>
        <div className="grid grid-cols-2 md:grid-cols-5 gap-4 mb-4">
          <StatItem label="Median" value={formatNumber(lot_baseline.median)} />
          <StatItem label="MAD" value={formatNumber(lot_baseline.mad)} />
          <StatItem label="Q1" value={formatNumber(lot_baseline.q1)} />
          <StatItem label="Q3" value={formatNumber(lot_baseline.q3)} />
          <StatItem label="IQR" value={formatNumber(lot_baseline.iqr)} />
        </div>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 pt-4 border-t border-slate-700/40">
          <StatItem label="Component Value (96h)" value={formatNumber(component.value_96h)} />
          <StatItem label="Robust Z-Score" value={formatNumber(lot_deviation.robust_z)} />
          <StatItem label="IQR Deviation" value={formatNumber(lot_deviation.iqr_deviation)} />
          <StatItem label="Relative Deviation" value={`${(lot_deviation.relative_lot_deviation * 100).toFixed(2)}%`} />
        </div>
        <p className="text-xs text-slate-500 mt-3">
          Statistics computed independently from {lot_baseline.component_count} components in {component.lot_id}. No data from other lots is used.
        </p>
      </SectionCard>

      {/* Anomaly Analysis */}
      <SectionCard title="Module A — Anomaly Detection" icon={<AlertTriangle className="w-5 h-5 text-amber-400" />}>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-4">
          <ScoreCard label="Statistical Score" value={anomaly.statistical_score} max={100} />
          <ScoreCard label="Isolation Forest Score" value={anomaly.isolation_forest_score} max={100} />
          <ScoreCard label="Final Anomaly Score" value={anomaly.anomaly_score} max={100} highlight />
        </div>
        <div className="flex items-center gap-3">
          <span className={`inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full text-sm font-medium ${anomalyColors.bg} ${anomalyColors.text} ${anomalyColors.border} border`}>
            {anomaly.anomaly_band} Anomaly
          </span>
          <span className="text-slate-400 text-sm">
            IF flagged: {anomaly.is_isolation_anomaly ? 'Yes' : 'No'} (raw score: {anomaly.raw_isolation_score.toFixed(4)})
          </span>
        </div>
      </SectionCard>

      {/* Prediction Analysis */}
      <SectionCard title="Module B — Early Drift Prediction (0h + 24h + 96h → 168h)" icon={<TrendingUp className="w-5 h-5 text-blue-400" />}>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-4">
          <StatItem label="Observed Drift 0→24h" value={formatNumber(prediction.observed_drift_0_24)} />
          <StatItem label="Observed Drift 24→96h" value={formatNumber(prediction.observed_drift_24_96)} />
          <StatItem label="Predicted Drift 96→168h" value={formatNumber(prediction.predicted_drift_96_168)} highlight />
          <StatItem label="Predicted 168h" value={formatNumber(prediction.predicted_168h)} highlight />
        </div>
        <div className="grid grid-cols-2 md:grid-cols-3 gap-4 pt-4 border-t border-slate-700/40">
          <StatItem label="Datasheet Limit" value={formatNumber(component.datasheet_limit)} />
          <StatItem label="Predicted Margin" value={formatNumber(prediction.predicted_margin)} />
          <StatItem label="Limit Ratio" value={prediction.predicted_limit_ratio.toFixed(4)} />
        </div>
      </SectionCard>

      {/* SHAP Explanation */}
      <SectionCard title="SHAP Explainability — Why This Decision?" icon={<Activity className="w-5 h-5 text-purple-400" />}>
        <div className="mb-4 text-sm text-slate-400">
          Base value: <span className="text-slate-200 font-mono">{explanation.base_value.toFixed(2)}</span> →
          Model output: <span className="text-slate-200 font-mono">{explanation.model_output.toFixed(2)}</span>
        </div>
        <div className="overflow-x-auto rounded-lg border border-slate-700/50">
          <table className="w-full text-sm">
            <thead className="bg-slate-900/60 text-slate-400">
              <tr>
                <th className="px-4 py-2.5 text-left font-medium">Feature</th>
                <th className="px-4 py-2.5 text-left font-medium">Actual Value</th>
                <th className="px-4 py-2.5 text-right font-medium">SHAP Contribution</th>
                <th className="px-4 py-2.5 text-center font-medium">Direction</th>
                <th className="px-4 py-2.5 text-right font-medium">Importance</th>
              </tr>
            </thead>
            <tbody>
              {explanation.features.map((f, i) => (
                <tr key={i} className="border-t border-slate-700/40">
                  <td className="px-4 py-2.5 text-white font-medium">{f.feature}</td>
                  <td className="px-4 py-2.5 text-slate-300 font-mono">{f.actual_value}</td>
                  <td className={`px-4 py-2.5 text-right font-mono ${f.shap_contribution > 0 ? 'text-red-400' : f.shap_contribution < 0 ? 'text-emerald-400' : 'text-slate-400'}`}>
                    {f.shap_contribution > 0 ? '+' : ''}{f.shap_contribution.toFixed(3)}
                  </td>
                  <td className="px-4 py-2.5 text-center">
                    <span className={`text-xs px-2 py-0.5 rounded-full ${f.direction === 'Increased Risk' ? 'bg-red-500/10 text-red-400' : f.direction === 'Reduced Risk' ? 'bg-emerald-500/10 text-emerald-400' : 'bg-slate-500/10 text-slate-400'}`}>
                      {f.direction}
                    </span>
                  </td>
                  <td className="px-4 py-2.5 text-right text-slate-300 font-mono">{f.importance.toFixed(3)}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        {/* SHAP bar visualization */}
        <div className="mt-4 space-y-2">
          {explanation.features.map((f, i) => (
            <div key={i} className="flex items-center gap-3">
              <span className="text-xs text-slate-400 w-28 truncate">{f.feature}</span>
              <div className="flex-1 h-5 bg-slate-900/40 rounded relative overflow-hidden">
                <div className="absolute left-1/2 top-0 bottom-0 w-px bg-slate-600" />
                {f.shap_contribution !== 0 && (
                  <div
                    className={`absolute top-0 bottom-0 ${f.shap_contribution > 0 ? 'bg-red-500/60' : 'bg-emerald-500/60'}`}
                    style={{
                      left: f.shap_contribution > 0 ? '50%' : `${50 - Math.abs(f.shap_contribution) * 5}%`,
                      width: `${Math.abs(f.shap_contribution) * 5}%`,
                    }}
                  />
                )}
              </div>
              <span className={`text-xs font-mono w-16 text-right ${f.shap_contribution > 0 ? 'text-red-400' : 'text-emerald-400'}`}>
                {f.shap_contribution > 0 ? '+' : ''}{f.shap_contribution.toFixed(2)}
              </span>
            </div>
          ))}
        </div>
      </SectionCard>

      {/* Decision Reason */}
      <SectionCard title="Decision Reason" icon={<AlertTriangle className="w-5 h-5 text-amber-400" />}>
        <p className="text-slate-300 leading-relaxed">{risk.decision_reason}</p>
        {risk.risk_factors.length > 0 && (
          <div className="mt-4 space-y-2">
            <p className="text-sm font-medium text-slate-400">Risk Factors:</p>
            {risk.risk_factors.map((rf, i) => (
              <div key={i} className="flex items-start gap-2 text-sm">
                <span className={`w-2 h-2 rounded-full mt-1.5 flex-shrink-0 ${
                  rf.severity === 'critical' ? 'bg-red-500' :
                  rf.severity === 'high' ? 'bg-orange-500' :
                  rf.severity === 'moderate' ? 'bg-amber-500' : 'bg-emerald-500'
                }`} />
                <span className="text-slate-300">
                  <span className="font-medium text-white">{rf.factor}</span> ({rf.value}): {rf.description}
                </span>
              </div>
            ))}
          </div>
        )}
        <div className="mt-4 p-4 bg-slate-900/40 rounded-lg border border-slate-700/40">
          <p className="text-sm text-slate-400 mb-2">Natural Language Explanation:</p>
          <p className="text-slate-200 leading-relaxed">{explanation.natural_language}</p>
        </div>
      </SectionCard>

      {/* Risk Components Breakdown */}
      <SectionCard title="Risk Score Breakdown" icon={<Activity className="w-5 h-5 text-blue-400" />}>
        <div className="space-y-3">
          {([
            ['Anomaly Evidence', risk.risk_components.anomaly_component],
            ['Lot Deviation Evidence', risk.risk_components.lot_deviation_component],
            ['Predicted Limit Evidence', risk.risk_components.predicted_limit_component],
            ['Future Drift Evidence', risk.risk_components.future_drift_component],
          ] as [string, number][]).map(([label, val]) => (
            <div key={label}>
              <div className="flex justify-between text-sm mb-1">
                <span className="text-slate-300">{label}</span>
                <span className="text-slate-400 font-mono">{val.toFixed(1)}/100</span>
              </div>
              <div className="h-2 bg-slate-700/50 rounded-full overflow-hidden">
                <div className={`h-full rounded-full ${getRiskBarColor(val)}`} style={{ width: `${val}%` }} />
              </div>
            </div>
          ))}
        </div>
      </SectionCard>
    </div>
  );
}

// --- Helper sub-components ---

function MeasurementCard({ label, value, highlight }: { label: string; value: string; highlight?: boolean }) {
  return (
    <div className={`rounded-lg border p-4 ${highlight ? 'bg-amber-500/5 border-amber-500/30' : 'bg-slate-800/50 border-slate-700/50'}`}>
      <p className="text-xs text-slate-400 mb-1">{label}</p>
      <p className={`text-xl font-bold font-mono ${highlight ? 'text-amber-400' : 'text-white'}`}>{value}</p>
    </div>
  );
}

function SectionCard({ title, icon, children }: { title: string; icon: React.ReactNode; children: React.ReactNode }) {
  return (
    <div className="bg-slate-800/50 border border-slate-700/50 rounded-xl p-5">
      <h2 className="text-lg font-semibold text-white flex items-center gap-2 mb-4">
        {icon}
        {title}
      </h2>
      {children}
    </div>
  );
}

function StatItem({ label, value, highlight }: { label: string; value: string; highlight?: boolean }) {
  return (
    <div>
      <p className="text-xs text-slate-400 mb-0.5">{label}</p>
      <p className={`text-lg font-semibold font-mono ${highlight ? 'text-amber-400' : 'text-white'}`}>{value}</p>
    </div>
  );
}

function ScoreCard({ label, value, max, highlight }: { label: string; value: number; max: number; highlight?: boolean }) {
  return (
    <div className={`rounded-lg border p-4 ${highlight ? 'bg-slate-900/60 border-slate-600' : 'bg-slate-900/40 border-slate-700/40'}`}>
      <p className="text-xs text-slate-400 mb-1">{label}</p>
      <p className={`text-2xl font-bold font-mono ${highlight ? 'text-white' : 'text-slate-200'}`}>{value.toFixed(1)}<span className="text-sm text-slate-500">/{max}</span></p>
      <div className="mt-2 h-1.5 bg-slate-700/50 rounded-full overflow-hidden">
        <div className={`h-full rounded-full ${getRiskBarColor(value)}`} style={{ width: `${(value / max) * 100}%` }} />
      </div>
    </div>
  );
}
