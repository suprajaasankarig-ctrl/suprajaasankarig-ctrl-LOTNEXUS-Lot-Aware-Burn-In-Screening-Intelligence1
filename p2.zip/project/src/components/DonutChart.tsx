// LOTNEXUS — Distribution Chart Component
// Simple SVG donut/bar chart for decision and anomaly distributions.

interface DonutData {
  name: string;
  value: number;
  color: string;
}

interface Props {
  data: DonutData[];
  title: string;
}

export function DonutChart({ data, title }: Props) {
  const total = data.reduce((s, d) => s + d.value, 0);
  const radius = 70;
  const strokeWidth = 28;
  const circumference = 2 * Math.PI * radius;

  let offset = 0;
  const segments = data.map((d) => {
    const fraction = total > 0 ? d.value / total : 0;
    const dash = fraction * circumference;
    const seg = {
      ...d,
      dash,
      gap: circumference - dash,
      offset: -offset,
      fraction,
    };
    offset += dash;
    return seg;
  });

  return (
    <div className="flex flex-col items-center">
      <h3 className="text-sm font-medium text-slate-400 mb-4">{title}</h3>
      <div className="relative">
        <svg width={180} height={180} className="-rotate-90">
          <circle cx={90} cy={90} r={radius} fill="none" stroke="#1e293b" strokeWidth={strokeWidth} />
          {total > 0 && segments.map((seg, i) => (
            <circle
              key={i}
              cx={90}
              cy={90}
              r={radius}
              fill="none"
              stroke={seg.color}
              strokeWidth={strokeWidth}
              strokeDasharray={`${seg.dash} ${seg.gap}`}
              strokeDashoffset={seg.offset}
              className="transition-all duration-500"
            />
          ))}
        </svg>
        <div className="absolute inset-0 flex flex-col items-center justify-center">
          <span className="text-2xl font-bold text-white">{total}</span>
          <span className="text-xs text-slate-500">Total</span>
        </div>
      </div>
      <div className="mt-4 space-y-2 w-full">
        {data.map((d) => (
          <div key={d.name} className="flex items-center justify-between text-sm">
            <div className="flex items-center gap-2">
              <span className="w-3 h-3 rounded-full" style={{ backgroundColor: d.color }} />
              <span className="text-slate-300">{d.name}</span>
            </div>
            <span className="text-slate-400 font-mono">{d.value}</span>
          </div>
        ))}
      </div>
    </div>
  );
}
