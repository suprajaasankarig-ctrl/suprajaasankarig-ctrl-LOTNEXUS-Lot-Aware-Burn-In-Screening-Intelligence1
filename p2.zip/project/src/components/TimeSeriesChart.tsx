// LOTNEXUS — Time-Series Chart Component
// Custom SVG chart showing burn-in trajectory: 0h, 24h, 96h observed + predicted 168h + datasheet limit.

import { useMemo } from 'react';
import type { ComponentAnalysis } from '@/lib/types';

interface Props {
  analysis: ComponentAnalysis;
}

export function TimeSeriesChart({ analysis }: Props) {
  const { timeseries } = analysis;
  const { hours, observed, predicted_168h, datasheet_limit, nominal_value } = timeseries;

  const width = 720;
  const height = 320;
  const margin = { top: 30, right: 50, bottom: 50, left: 60 };
  const chartW = width - margin.left - margin.right;
  const chartH = height - margin.top - margin.bottom;

  const allValues = [...observed.filter((v): v is number => v !== null), predicted_168h, datasheet_limit, nominal_value];
  const minVal = Math.min(...allValues) * 0.95;
  const maxVal = Math.max(...allValues) * 1.05;
  const valRange = maxVal - minVal || 1;

  const xScale = (h: number) => margin.left + (h / 168) * chartW;
  const yScale = (v: number) => margin.top + chartH - ((v - minVal) / valRange) * chartH;

  // Build the observed line path
  const observedPoints = hours.map((h, i) => ({ x: xScale(h), y: observed[i] !== null ? yScale(observed[i]!) : null }));
  const observedPath = observedPoints
    .filter((p) => p.y !== null)
    .map((p, i) => `${i === 0 ? 'M' : 'L'} ${p.x} ${p.y}`)
    .join(' ');

  // Predicted point at 168h
  const predictedPoint = { x: xScale(168), y: yScale(predicted_168h) };
  const lastObservedPoint = observedPoints[2]; // 96h point

  // Dashed line from 96h to predicted 168h
  const predictedLine = lastObservedPoint && lastObservedPoint.y !== null
    ? `M ${lastObservedPoint.x} ${lastObservedPoint.y} L ${predictedPoint.x} ${predictedPoint.y}`
    : '';

  // Grid lines
  const yTicks = useMemo(() => {
    const ticks: number[] = [];
    const step = valRange / 5;
    for (let i = 0; i <= 5; i++) ticks.push(minVal + step * i);
    return ticks;
  }, [minVal, valRange]);

  return (
    <div className="w-full overflow-x-auto">
      <svg width={width} height={height} className="mx-auto" style={{ maxWidth: '100%' }}>
        {/* Grid */}
        {yTicks.map((t, i) => (
          <g key={i}>
            <line
              x1={margin.left}
              y1={yScale(t)}
              x2={width - margin.right}
              y2={yScale(t)}
              stroke="#1f2937"
              strokeWidth={1}
              strokeDasharray="2 4"
            />
            <text x={margin.left - 8} y={yScale(t) + 4} fill="#6b7280" fontSize={11} textAnchor="end">
              {t.toFixed(1)}
            </text>
          </g>
        ))}

        {/* X axis labels */}
        {hours.map((h) => (
          <text key={h} x={xScale(h)} y={height - margin.bottom + 20} fill="#9ca3af" fontSize={12} textAnchor="middle">
            {h}h
          </text>
        ))}

        {/* Datasheet limit line */}
        <line
          x1={margin.left}
          y1={yScale(datasheet_limit)}
          x2={width - margin.right}
          y2={yScale(datasheet_limit)}
          stroke="#ef4444"
          strokeWidth={2}
          strokeDasharray="6 4"
        />
        <text x={width - margin.right + 6} y={yScale(datasheet_limit) + 4} fill="#ef4444" fontSize={10}>
          Limit
        </text>

        {/* Nominal value line */}
        <line
          x1={margin.left}
          y1={yScale(nominal_value)}
          x2={width - margin.right}
          y2={yScale(nominal_value)}
          stroke="#3b82f6"
          strokeWidth={1}
          strokeDasharray="3 3"
          opacity={0.5}
        />
        <text x={width - margin.right + 6} y={yScale(nominal_value) + 4} fill="#3b82f6" fontSize={10}>
          Nominal
        </text>

        {/* Observed line */}
        <path d={observedPath} fill="none" stroke="#60a5fa" strokeWidth={2.5} />

        {/* Observed points */}
        {observedPoints.map((p, i) =>
          p.y !== null ? (
            <g key={i}>
              <circle cx={p.x} cy={p.y} r={5} fill="#60a5fa" stroke="#1e293b" strokeWidth={2} />
              <text x={p.x} y={p.y - 12} fill="#93c5fd" fontSize={10} textAnchor="middle">
                {observed[i]?.toFixed(2)}
              </text>
            </g>
          ) : null
        )}

        {/* Predicted dashed line */}
        <path d={predictedLine} fill="none" stroke="#f59e0b" strokeWidth={2} strokeDasharray="5 5" />

        {/* Predicted point */}
        <circle cx={predictedPoint.x} cy={predictedPoint.y} r={6} fill="#f59e0b" stroke="#1e293b" strokeWidth={2} />
        <text x={predictedPoint.x} y={predictedPoint.y - 14} fill="#fbbf24" fontSize={11} textAnchor="middle" fontWeight="bold">
          {predicted_168h.toFixed(2)}
        </text>

        {/* Legend */}
        <g transform={`translate(${margin.left}, ${margin.top - 18})`}>
          <circle cx={6} cy={6} r={4} fill="#60a5fa" />
          <text x={16} y={10} fill="#9ca3af" fontSize={11}>Observed</text>
          <circle cx={90} cy={6} r={4} fill="#f59e0b" />
          <text x={100} y={10} fill="#9ca3af" fontSize={11}>Predicted 168h</text>
          <line x1={186} y1={6} x2={206} y2={6} stroke="#ef4444" strokeWidth={2} strokeDasharray="4 3" />
          <text x={212} y={10} fill="#9ca3af" fontSize={11}>Datasheet Limit</text>
          <line x1={308} y1={6} x2={328} y2={6} stroke="#3b82f6" strokeWidth={1} strokeDasharray="3 3" opacity={0.5} />
          <text x={334} y={10} fill="#9ca3af" fontSize={11}>Nominal</text>
        </g>
      </svg>
    </div>
  );
}
