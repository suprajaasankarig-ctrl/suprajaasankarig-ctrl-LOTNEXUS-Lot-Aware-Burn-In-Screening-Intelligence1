// LOTNEXUS — Model Metrics Dashboard
// Shows MAE, RMSE, R² for XGBoost vs Linear Regression baseline, plus classification metrics.

import { useEffect, useState } from 'react';
import { ArrowLeft, BarChart3, TrendingUp, Target, GitBranch } from 'lucide-react';
import { getMetrics } from '@/lib/pipeline';
import type { ModelMetrics } from '@/lib/types';

interface Props {
  onBack: () => void;
}

export function MetricsDashboard({ onBack }: Props) {
  const [metrics, setMetrics] = useState<ModelMetrics | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    getMetrics().then((m) => {
      setMetrics(m);
      setLoading(false);
    });
  }, []);

  if (loading || !metrics) {
    return <div className="flex items-center justify-center py-20"><div className="text-slate-400">Computing model metrics...</div></div>;
  }

  return (
    <div className="space-y-6">
      <button onClick={onBack} className="flex items-center gap-2 text-slate-400 hover:text-white transition-colors text-sm">
        <ArrowLeft className="w-4 h-4" /> Back to Dashboard
      </button>

      <div className="bg-slate-800/50 border border-slate-700/50 rounded-xl p-5">
        <h1 className="text-2xl font-bold text-white flex items-center gap-3 mb-6">
          <BarChart3 className="w-7 h-7 text-blue-400" />
          Model Evaluation Metrics
        </h1>

        {/* Prediction Metrics Comparison */}
        <h2 className="text-lg font-semibold text-white flex items-center gap-2 mb-4">
          <TrendingUp className="w-5 h-5 text-blue-400" />
          Module B — Prediction Model Comparison
        </h2>
        <p className="text-sm text-slate-400 mb-4">
          XGBoost (Gradient Boosting) vs Linear Regression baseline. Target: value_168h from features [value_0h, value_24h, value_96h, drift_0_to_24, drift_24_to_96, total_drift_0_to_96]. Evaluated on 20% held-out test set.
        </p>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
          {/* XGBoost */}
          <div className="bg-slate-900/40 rounded-lg p-5 border border-blue-500/30">
            <h3 className="text-lg font-semibold text-blue-400 mb-4">XGBoost (Gradient Boosting)</h3>
            <MetricRow label="MAE" value={metrics.mae.toFixed(4)} />
            <MetricRow label="RMSE" value={metrics.rmse.toFixed(4)} />
            <MetricRow label="R²" value={metrics.r2.toFixed(4)} />
          </div>

          {/* Linear Regression */}
          <div className="bg-slate-900/40 rounded-lg p-5 border border-slate-700/40">
            <h3 className="text-lg font-semibold text-slate-300 mb-4">Linear Regression (Baseline)</h3>
            <MetricRow label="MAE" value={metrics.baseline_mae.toFixed(4)} />
            <MetricRow label="RMSE" value={metrics.baseline_rmse.toFixed(4)} />
            <MetricRow label="R²" value={metrics.baseline_r2.toFixed(4)} />
          </div>
        </div>

        {/* Comparison bar */}
        <div className="bg-slate-900/40 rounded-lg p-4 mb-8">
          <div className="grid grid-cols-3 gap-4 text-center">
            <div>
              <p className="text-xs text-slate-400 mb-1">MAE Improvement</p>
              <p className={`text-lg font-bold ${metrics.mae < metrics.baseline_mae ? 'text-emerald-400' : 'text-red-400'}`}>
                {(((metrics.baseline_mae - metrics.mae) / metrics.baseline_mae) * 100).toFixed(1)}%
              </p>
            </div>
            <div>
              <p className="text-xs text-slate-400 mb-1">RMSE Improvement</p>
              <p className={`text-lg font-bold ${metrics.rmse < metrics.baseline_rmse ? 'text-emerald-400' : 'text-red-400'}`}>
                {(((metrics.baseline_rmse - metrics.rmse) / metrics.baseline_rmse) * 100).toFixed(1)}%
              </p>
            </div>
            <div>
              <p className="text-xs text-slate-400 mb-1">R² Improvement</p>
              <p className={`text-lg font-bold ${metrics.r2 > metrics.baseline_r2 ? 'text-emerald-400' : 'text-red-400'}`}>
                {(((metrics.r2 - metrics.baseline_r2) / Math.abs(metrics.baseline_r2)) * 100).toFixed(1)}%
              </p>
            </div>
          </div>
        </div>

        {/* Classification Metrics */}
        <h2 className="text-lg font-semibold text-white flex items-center gap-2 mb-4">
          <Target className="w-5 h-5 text-amber-400" />
          Risk Engine — Classification Metrics
        </h2>
        <p className="text-sm text-slate-400 mb-4">
          Using defect_label as ground truth. In safety-oriented screening, false negatives (missed defects) are more serious than false positives (unnecessary monitoring).
        </p>

        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
          <MetricCard label="Recall" value={`${(metrics.recall * 100).toFixed(1)}%`} highlight={metrics.recall >= 0.8} />
          <MetricCard label="False Negative Rate" value={`${(metrics.false_negative_rate * 100).toFixed(1)}%`} highlight={metrics.false_negative_rate <= 0.2} />
          <MetricCard label="Precision" value={`${(metrics.precision * 100).toFixed(1)}%`} />
          <MetricCard label="F1 Score" value={metrics.f1.toFixed(4)} />
        </div>

        {/* Screening Metrics */}
        <h2 className="text-lg font-semibold text-white flex items-center gap-2 mb-4">
          <GitBranch className="w-5 h-5 text-emerald-400" />
          Screening Metrics
        </h2>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          <MetricCard label="Rescreening Rate" value={`${(metrics.rescreening_rate * 100).toFixed(1)}%`} />
          <MetricCard label="Total Components" value={String(metrics.total_components)} />
          <MetricCard label="Early Rejects" value={String(metrics.early_reject_count)} />
          <MetricCard label="Monitor" value={String(metrics.monitor_count)} />
        </div>

        <p className="text-xs text-slate-500 mt-6">
          Rescreening Rate = Monitor components / Total components. This represents the fraction of components
          sent for additional monitoring rather than immediate pass or reject.
        </p>
      </div>
    </div>
  );
}

function MetricRow({ label, value }: { label: string; value: string }) {
  return (
    <div className="flex justify-between py-2 border-b border-slate-700/30 last:border-0">
      <span className="text-slate-400">{label}</span>
      <span className="text-white font-mono font-semibold">{value}</span>
    </div>
  );
}

function MetricCard({ label, value, highlight }: { label: string; value: string; highlight?: boolean }) {
  return (
    <div className={`rounded-lg border p-4 ${highlight ? 'bg-emerald-500/5 border-emerald-500/30' : 'bg-slate-900/40 border-slate-700/40'}`}>
      <p className="text-xs text-slate-400 mb-1">{label}</p>
      <p className={`text-xl font-bold font-mono ${highlight ? 'text-emerald-400' : 'text-white'}`}>{value}</p>
    </div>
  );
}
