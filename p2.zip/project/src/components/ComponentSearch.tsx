// LOTNEXUS — Component Search
// Search by component_id, lot_id, component_type, or decision.

import { useState, useEffect, useCallback } from 'react';
import { Search, Filter } from 'lucide-react';
import { searchComponents } from '@/lib/pipeline';
import type { ComponentSummary } from '@/lib/types';
import { getDecisionColor } from '@/lib/uiHelpers';

interface Props {
  onSelectComponent: (id: string) => void;
}

export function ComponentSearch({ onSelectComponent }: Props) {
  const [query, setQuery] = useState('');
  const [results, setResults] = useState<ComponentSummary[]>([]);
  const [lotFilter, setLotFilter] = useState('');
  const [decisionFilter, setDecisionFilter] = useState('');
  const [loading, setLoading] = useState(false);
  const [showResults, setShowResults] = useState(false);

  const doSearch = useCallback(async () => {
    setLoading(true);
    const res = await searchComponents(query, { lotId: lotFilter || undefined, decision: decisionFilter || undefined });
    setResults(res);
    setLoading(false);
    setShowResults(true);
  }, [query, lotFilter, decisionFilter]);

  useEffect(() => {
    doSearch();
  }, [doSearch]);

  return (
    <div className="bg-slate-800/50 border border-slate-700/50 rounded-xl p-5">
      <div className="flex items-center gap-3 mb-4">
        <Search className="w-5 h-5 text-slate-400" />
        <h2 className="text-lg font-semibold text-white">Component Search</h2>
      </div>

      <div className="flex flex-col sm:flex-row gap-3 mb-4">
        <div className="flex-1 relative">
          <input
            type="text"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Search by Component ID (e.g. C003)..."
            className="w-full bg-slate-900/60 border border-slate-700 rounded-lg px-4 py-2.5 text-white placeholder-slate-500 focus:outline-none focus:border-blue-500 transition-colors"
          />
        </div>
        <select
          value={lotFilter}
          onChange={(e) => setLotFilter(e.target.value)}
          className="bg-slate-900/60 border border-slate-700 rounded-lg px-3 py-2.5 text-white focus:outline-none focus:border-blue-500"
        >
          <option value="">All Lots</option>
          {Array.from({ length: 10 }, (_, i) => `LOT-${String(i + 1).padStart(2, '0')}`).map((lot) => (
            <option key={lot} value={lot}>{lot}</option>
          ))}
        </select>
        <select
          value={decisionFilter}
          onChange={(e) => setDecisionFilter(e.target.value)}
          className="bg-slate-900/60 border border-slate-700 rounded-lg px-3 py-2.5 text-white focus:outline-none focus:border-blue-500"
        >
          <option value="">All Decisions</option>
          <option value="PASS">PASS</option>
          <option value="MONITOR">MONITOR</option>
          <option value="EARLY_REJECT">EARLY REJECT</option>
        </select>
      </div>

      {loading && <p className="text-slate-400 text-sm">Searching...</p>}

      {showResults && !loading && (
        <div className="overflow-x-auto rounded-lg border border-slate-700/50">
          <table className="w-full text-sm">
            <thead className="bg-slate-900/60 text-slate-400">
              <tr>
                <th className="px-4 py-2.5 text-left font-medium">Component ID</th>
                <th className="px-4 py-2.5 text-left font-medium">Lot</th>
                <th className="px-4 py-2.5 text-left font-medium">Type</th>
                <th className="px-4 py-2.5 text-right font-medium">Anomaly</th>
                <th className="px-4 py-2.5 text-right font-medium">Pred 168h</th>
                <th className="px-4 py-2.5 text-right font-medium">Risk</th>
                <th className="px-4 py-2.5 text-center font-medium">Decision</th>
              </tr>
            </thead>
            <tbody>
              {results.length === 0 && (
                <tr>
                  <td colSpan={7} className="px-4 py-8 text-center text-slate-500">No components found</td>
                </tr>
              )}
              {results.slice(0, 50).map((c) => {
                const colors = getDecisionColor(c.decision);
                return (
                  <tr
                    key={c.component_id}
                    onClick={() => onSelectComponent(c.component_id)}
                    className="border-t border-slate-700/40 hover:bg-slate-700/30 cursor-pointer transition-colors"
                  >
                    <td className="px-4 py-2.5 text-white font-mono">{c.component_id}</td>
                    <td className="px-4 py-2.5 text-slate-300 font-mono">{c.lot_id}</td>
                    <td className="px-4 py-2.5 text-slate-300">{c.component_type}</td>
                    <td className="px-4 py-2.5 text-right text-slate-300 font-mono">{c.anomaly_score.toFixed(1)}</td>
                    <td className="px-4 py-2.5 text-right text-slate-300 font-mono">{c.predicted_168h.toFixed(2)}</td>
                    <td className="px-4 py-2.5 text-right text-slate-300 font-mono">{c.risk_score.toFixed(1)}</td>
                    <td className="px-4 py-2.5 text-center">
                      <span className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-medium ${colors.bg} ${colors.text} ${colors.border} border`}>
                        <span className={`w-1.5 h-1.5 rounded-full ${colors.dot}`} />
                        {c.decision.replace('_', ' ')}
                      </span>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
          {results.length > 50 && (
            <p className="text-center text-slate-500 text-xs py-2">Showing first 50 of {results.length} results</p>
          )}
        </div>
      )}
    </div>
  );
}
