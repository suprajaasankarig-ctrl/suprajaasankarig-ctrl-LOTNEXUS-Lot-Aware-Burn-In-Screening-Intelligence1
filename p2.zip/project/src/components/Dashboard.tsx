// LOTNEXUS — Dashboard Overview
// Summary cards, risk distribution, anomaly distribution, lot overview, high-risk components table.

import { useEffect, useState } from 'react';
import { Cpu, AlertTriangle, ShieldCheck, Eye, Boxes, Layers, TrendingUp } from 'lucide-react';
import { getDashboardData } from '@/lib/pipeline';
import type { DashboardData } from '@/lib/types';
import { DonutChart } from './DonutChart';
import { getDecisionColor, getRiskColor } from '@/lib/uiHelpers';

interface Props {
  onSelectComponent: (id: string) => void;
  onNavigateLots: () => void;
}

export function Dashboard({ onSelectComponent, onNavigateLots }: Props) {
  const [data, setData] = useState<DashboardData | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    getDashboardData().then((d) => {
      setData(d);
      setLoading(false);
    });
  }, []);

  if (loading || !data) {
    return (
      <div className="flex items-center justify-center py-20">
        <div className="text-slate-400">Training models and computing analysis...</div>
      </div>
    );
  }

  const { metrics } = data;
  const highRiskComponents = data.components
    .filter((c) => c.decision !== 'PASS')
    .sort((a, b) => b.risk_score - a.risk_score)
    .slice(0, 15);

  return (
    <div className="space-y-6">
      {/* Summary Cards */}
      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
        <SummaryCard icon={<Cpu className="w-5 h-5" />} label="Total Components" value={metrics.total_components} color="blue" />
        <SummaryCard icon={<AlertTriangle className="w-5 h-5" />} label="High-Risk" value={metrics.high_risk_count} color="red" />
        <SummaryCard icon={<ShieldCheck className="w-5 h-5" />} label="Early Rejects" value={metrics.early_reject_count} color="red" />
        <SummaryCard icon={<Eye className="w-5 h-5" />} label="Monitor" value={metrics.monitor_count} color="amber" />
        <SummaryCard icon={<ShieldCheck className="w-5 h-5" />} label="Pass" value={metrics.pass_count} color="emerald" />
        <SummaryCard icon={<Layers className="w-5 h-5" />} label="Lots Analysed" value={metrics.lots_analysed} color="blue" />
      </div>

      {/* Distributions */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bg-slate-800/50 border border-slate-700/50 rounded-xl p-5">
          <DonutChart data={data.decisionDistribution} title="Risk Decision Distribution" />
        </div>
        <div className="bg-slate-800/50 border border-slate-700/50 rounded-xl p-5">
          <DonutChart data={data.anomalyDistribution} title="Anomaly Distribution" />
        </div>
      </div>

      {/* Lot Overview */}
      <div className="bg-slate-800/50 border border-slate-700/50 rounded-xl p-5">
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-lg font-semibold text-white flex items-center gap-2">
            <Boxes className="w-5 h-5 text-blue-400" />
            Lot Overview
          </h2>
          <button onClick={onNavigateLots} className="text-sm text-blue-400 hover:text-blue-300 transition-colors">
            View Lot Analysis →
          </button>
        </div>
        <div className="overflow-x-auto rounded-lg border border-slate-700/50">
          <table className="w-full text-sm">
            <thead className="bg-slate-900/60 text-slate-400">
              <tr>
                <th className="px-4 py-2.5 text-left font-medium">Lot ID</th>
                <th className="px-4 py-2.5 text-left font-medium">Type</th>
                <th className="px-4 py-2.5 text-right font-medium">Components</th>
                <th className="px-4 py-2.5 text-right font-medium">Median</th>
                <th className="px-4 py-2.5 text-right font-medium">MAD</th>
                <th className="px-4 py-2.5 text-right font-medium">IQR</th>
                <th className="px-4 py-2.5 text-right font-medium">High-Risk</th>
              </tr>
            </thead>
            <tbody>
              {data.lots.map((lot) => (
                <tr
                  key={lot.lot_id}
                  onClick={onNavigateLots}
                  className="border-t border-slate-700/40 hover:bg-slate-700/30 cursor-pointer transition-colors"
                >
                  <td className="px-4 py-2.5 text-white font-mono">{lot.lot_id}</td>
                  <td className="px-4 py-2.5 text-slate-300">{lot.component_type}</td>
                  <td className="px-4 py-2.5 text-right text-slate-300 font-mono">{lot.component_count}</td>
                  <td className="px-4 py-2.5 text-right text-slate-300 font-mono">{lot.median.toFixed(2)}</td>
                  <td className="px-4 py-2.5 text-right text-slate-300 font-mono">{lot.mad.toFixed(2)}</td>
                  <td className="px-4 py-2.5 text-right text-slate-300 font-mono">{lot.iqr.toFixed(2)}</td>
                  <td className={`px-4 py-2.5 text-right font-mono ${lot.high_risk_count > 5 ? 'text-red-400' : lot.high_risk_count > 2 ? 'text-amber-400' : 'text-emerald-400'}`}>
                    {lot.high_risk_count}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* High-Risk Components */}
      <div className="bg-slate-800/50 border border-slate-700/50 rounded-xl p-5">
        <h2 className="text-lg font-semibold text-white flex items-center gap-2 mb-4">
          <TrendingUp className="w-5 h-5 text-red-400" />
          High-Risk Components
        </h2>
        <div className="overflow-x-auto rounded-lg border border-slate-700/50">
          <table className="w-full text-sm">
            <thead className="bg-slate-900/60 text-slate-400">
              <tr>
                <th className="px-4 py-2.5 text-left font-medium">Component ID</th>
                <th className="px-4 py-2.5 text-left font-medium">Lot</th>
                <th className="px-4 py-2.5 text-right font-medium">Anomaly Score</th>
                <th className="px-4 py-2.5 text-right font-medium">Predicted 168h</th>
                <th className="px-4 py-2.5 text-right font-medium">Risk Score</th>
                <th className="px-4 py-2.5 text-center font-medium">Decision</th>
              </tr>
            </thead>
            <tbody>
              {highRiskComponents.map((c) => {
                const colors = getDecisionColor(c.decision);
                return (
                  <tr
                    key={c.component_id}
                    onClick={() => onSelectComponent(c.component_id)}
                    className="border-t border-slate-700/40 hover:bg-slate-700/30 cursor-pointer transition-colors"
                  >
                    <td className="px-4 py-2.5 text-white font-mono">{c.component_id}</td>
                    <td className="px-4 py-2.5 text-slate-300 font-mono">{c.lot_id}</td>
                    <td className="px-4 py-2.5 text-right text-slate-300 font-mono">{c.anomaly_score.toFixed(1)}</td>
                    <td className="px-4 py-2.5 text-right text-slate-300 font-mono">{c.predicted_168h.toFixed(2)}</td>
                    <td className={`px-4 py-2.5 text-right font-mono font-bold ${getRiskColor(c.risk_score)}`}>{c.risk_score.toFixed(1)}</td>
                    <td className="px-4 py-2.5 text-center">
                      <span className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-medium ${colors.bg} ${colors.text} ${colors.border} border`}>
                        <span className={`w-1.5 h-1.5 rounded-full ${colors.dot}`} />
                        {c.decision.replace('_', ' ')}
                      </span>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}

function SummaryCard({ icon, label, value, color }: { icon: React.ReactNode; label: string; value: number; color: string }) {
  const colorMap: Record<string, string> = {
    blue: 'text-blue-400 bg-blue-500/10 border-blue-500/30',
    red: 'text-red-400 bg-red-500/10 border-red-500/30',
    amber: 'text-amber-400 bg-amber-500/10 border-amber-500/30',
    emerald: 'text-emerald-400 bg-emerald-500/10 border-emerald-500/30',
  };
  return (
    <div className={`rounded-xl border p-4 ${colorMap[color]}`}>
      <div className="flex items-center gap-2 mb-2">
        {icon}
      </div>
      <p className="text-2xl font-bold text-white">{value}</p>
      <p className="text-xs text-slate-400 mt-1">{label}</p>
    </div>
  );
}
