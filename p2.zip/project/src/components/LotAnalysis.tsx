// LOTNEXUS — Lot Analysis Page
// Shows lot-specific statistics and distribution of component values for a selected lot.

import { useEffect, useState, useMemo } from 'react';
import { ArrowLeft, Boxes, Activity } from 'lucide-react';
import { getLotBaselines, getDashboardData } from '@/lib/pipeline';
import type { LotBaseline, ComponentSummary } from '@/lib/types';

interface Props {
  onBack: () => void;
  onSelectComponent: (id: string) => void;
}

export function LotAnalysis({ onBack, onSelectComponent }: Props) {
  const [lots, setLots] = useState<LotBaseline[]>([]);
  const [selectedLot, setSelectedLot] = useState<string>('');
  const [components, setComponents] = useState<ComponentSummary[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    getLotBaselines().then((l) => {
      setLots(l);
      if (l.length > 0) setSelectedLot(l[0].lot_id);
      setLoading(false);
    });
  }, []);

  useEffect(() => {
    if (!selectedLot) return;
    getDashboardData().then((d) => {
      setComponents(d.components.filter((c) => c.lot_id === selectedLot));
    });
  }, [selectedLot]);

  const currentLot = useMemo(() => lots.find((l) => l.lot_id === selectedLot), [lots, selectedLot]);

  if (loading) {
    return <div className="flex items-center justify-center py-20 text-slate-20"><div className="text-slate-400">Loading lot data...</div></div>;
  }

  // Build a simple histogram from the components' predicted values
  const predictedValues = components.map((c) => c.predicted_168h);
  const min = Math.min(...predictedValues, currentLot?.median ?? 0);
  const max = Math.max(...predictedValues, currentLot?.median ?? 0);
  const range = max - min || 1;
  const numBins = 15;
  const binSize = range / numBins;
  const bins = Array(numBins).fill(0);
  for (const v of predictedValues) {
    const idx = Math.min(numBins - 1, Math.floor((v - min) / binSize));
    bins[idx]++;
  }
  const maxBin = Math.max(...bins, 1);

  return (
    <div className="space-y-6">
      <button onClick={onBack} className="flex items-center gap-2 text-slate-400 hover:text-white transition-colors text-sm">
        <ArrowLeft className="w-4 h-4" /> Back to Dashboard
      </button>

      <div className="bg-slate-800/50 border border-slate-700/50 rounded-xl p-5">
        <h1 className="text-2xl font-bold text-white flex items-center gap-3 mb-4">
          <Boxes className="w-7 h-7 text-blue-400" />
          Lot Analysis
        </h1>

        {/* Lot selector */}
        <div className="flex flex-wrap gap-2 mb-6">
          {lots.map((lot) => (
            <button
              key={lot.lot_id}
              onClick={() => setSelectedLot(lot.lot_id)}
              className={`px-4 py-2 rounded-lg text-sm font-mono transition-colors ${
                selectedLot === lot.lot_id
                  ? 'bg-blue-500 text-white'
                  : 'bg-slate-700/50 text-slate-300 hover:bg-slate-700'
              }`}
            >
              {lot.lot_id}
            </button>
          ))}
        </div>

        {currentLot && (
          <>
            {/* Lot statistics */}
            <div className="grid grid-cols-2 md:grid-cols-7 gap-4 mb-6">
              <LotStat label="Lot ID" value={currentLot.lot_id} />
              <LotStat label="Components" value={String(currentLot.component_count)} />
              <LotStat label="Median" value={currentLot.median.toFixed(4)} />
              <LotStat label="MAD" value={currentLot.mad.toFixed(4)} />
              <LotStat label="Q1" value={currentLot.q1.toFixed(4)} />
              <LotStat label="Q3" value={currentLot.q3.toFixed(4)} />
              <LotStat label="IQR" value={currentLot.iqr.toFixed(4)} />
            </div>
            <p className="text-xs text-slate-500 mb-6">
              All statistics are computed independently from {currentLot.component_count} components in {currentLot.lot_id}.
              No data from other lots is used. MAD = Mean Absolute Deviation = mean(|x - mean(x)|).
            </p>

            {/* Histogram */}
            <div className="bg-slate-900/40 rounded-lg p-4 mb-6">
              <h3 className="text-sm font-medium text-slate-400 mb-3 flex items-center gap-2">
                <Activity className="w-4 h-4 text-blue-400" />
                Predicted 168h Value Distribution for {currentLot.lot_id}
              </h3>
              <div className="flex items-end gap-1 h-40">
                {bins.map((count, i) => (
                  <div key={i} className="flex-1 flex flex-col items-center justify-end">
                    <div
                      className="w-full bg-blue-500/60 rounded-t hover:bg-blue-400 transition-colors"
                      style={{ height: `${(count / maxBin) * 100}%` }}
                      title={`${(min + i * binSize).toFixed(2)} - ${(min + (i + 1) * binSize).toFixed(2)}: ${count} components`}
                    />
                  </div>
                ))}
              </div>
              <div className="flex justify-between mt-2 text-xs text-slate-500">
                <span>{min.toFixed(2)}</span>
                <span>{max.toFixed(2)}</span>
              </div>
            </div>

            {/* Components table */}
            <div className="overflow-x-auto rounded-lg border border-slate-700/50">
              <table className="w-full text-sm">
                <thead className="bg-slate-900/60 text-slate-400">
                  <tr>
                    <th className="px-4 py-2.5 text-left font-medium">Component ID</th>
                    <th className="px-4 py-2.5 text-right font-medium">Anomaly Score</th>
                    <th className="px-4 py-2.5 text-right font-medium">Predicted 168h</th>
                    <th className="px-4 py-2.5 text-right font-medium">Risk Score</th>
                    <th className="px-4 py-2.5 text-center font-medium">Decision</th>
                  </tr>
                </thead>
                <tbody>
                  {components.map((c) => {
                    const decisionColor = c.decision === 'PASS' ? 'text-emerald-400' : c.decision === 'MONITOR' ? 'text-amber-400' : 'text-red-400';
                    return (
                      <tr
                        key={c.component_id}
                        onClick={() => onSelectComponent(c.component_id)}
                        className="border-t border-slate-700/40 hover:bg-slate-700/30 cursor-pointer transition-colors"
                      >
                        <td className="px-4 py-2.5 text-white font-mono">{c.component_id}</td>
                        <td className="px-4 py-2.5 text-right text-slate-300 font-mono">{c.anomaly_score.toFixed(1)}</td>
                        <td className="px-4 py-2.5 text-right text-slate-300 font-mono">{c.predicted_168h.toFixed(2)}</td>
                        <td className={`px-4 py-2.5 text-right font-mono font-bold ${decisionColor}`}>{c.risk_score.toFixed(1)}</td>
                        <td className={`px-4 py-2.5 text-center font-medium ${decisionColor}`}>{c.decision.replace('_', ' ')}</td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </>
        )}
      </div>
    </div>
  );
}

function LotStat({ label, value }: { label: string; value: string }) {
  return (
    <div className="bg-slate-900/40 rounded-lg p-3 border border-slate-700/40">
      <p className="text-xs text-slate-400 mb-1">{label}</p>
      <p className="text-lg font-semibold text-white font-mono">{value}</p>
    </div>
  );
}
