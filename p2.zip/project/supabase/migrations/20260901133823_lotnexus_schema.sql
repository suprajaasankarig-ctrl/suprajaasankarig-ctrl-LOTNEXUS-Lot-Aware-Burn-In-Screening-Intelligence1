/*
# LOTNEXUS — Lot-Aware Component Burn-In & Screening Intelligence

## Overview
Creates the database schema for a semiconductor burn-in screening decision-support system.
Stores synthetic burn-in measurement data, lot baselines, predictions, and risk assessments.

## New Tables
1. `lots` — manufacturing lot metadata and baseline statistics
   - lot_id (text, primary key): unique lot identifier (e.g. LOT-01)
   - component_type (text): type of component in this lot
   - component_count (int): number of components in the lot
   - median (float8): lot-specific median of value_96h
   - mad (float8): Mean Absolute Deviation of the lot
   - q1 (float8): first quartile
   - q3 (float8): third quartile
   - iqr (float8): interquartile range
   - high_risk_count (int): number of high-risk components in the lot
   - created_at (timestamptz)

2. `components` — individual component burn-in measurements
   - id (uuid, primary key)
   - component_id (text, unique): human-readable ID (e.g. C003)
   - lot_id (text, FK to lots): which lot this component belongs to
   - component_type (text): type of component
   - parameter_name (text): measured parameter (e.g. leakage_current)
   - nominal_value (float8): nominal/datasheet typical value
   - datasheet_limit (float8): upper datasheet limit
   - temperature (float8): burn-in temperature in °C
   - voltage (float8): burn-in voltage in V
   - value_0h (float8): measurement at 0 hours
   - value_24h (float8): measurement at 24 hours
   - value_96h (float8): measurement at 96 hours
   - value_168h (float8): measurement at 168 hours (final screening)
   - manufacturing_shift (text): shift identifier
   - test_date (date): date of burn-in test
   - defect_label (text): ground-truth label (normal/defective)
   - failure_type (text): type of failure if defective
   - created_at (timestamptz)

3. `predictions` — Module B prediction results
   - id (uuid, primary key)
   - component_id (text, FK to components): which component
   - predicted_168h (float8): predicted value at 168h
   - predicted_drift_96_168 (float8): predicted drift from 96h to 168h
   - predicted_margin (float8): datasheet_limit - predicted_168h
   - predicted_limit_ratio (float8): predicted_168h / datasheet_limit
   - created_at (timestamptz)

4. `risk_assessments` — combined risk engine results
   - id (uuid, primary key)
   - component_id (text, FK to components): which component
   - statistical_score (float8): statistical anomaly score 0-100
   - isolation_forest_score (float8): isolation forest score 0-100
   - anomaly_score (float8): final combined anomaly score 0-100
   - lot_deviation (float8): robust z-score deviation from lot
   - risk_score (float8): final risk score 0-100
   - decision (text): PASS / MONITOR / EARLY_REJECT
   - decision_reason (text): human-readable reason
   - risk_factors (jsonb): array of risk factor descriptions
   - shap_values (jsonb): SHAP explanation data
   - created_at (timestamptz)

## Security
- RLS enabled on all tables
- Single-tenant (no auth): anon + authenticated can read/write all data
- Data is intentionally public/shared for this prototype
*/

-- Lots table
CREATE TABLE IF NOT EXISTS lots (
  lot_id text PRIMARY KEY,
  component_type text NOT NULL,
  component_count integer NOT NULL DEFAULT 0,
  median float8 NOT NULL DEFAULT 0,
  mad float8 NOT NULL DEFAULT 0,
  q1 float8 NOT NULL DEFAULT 0,
  q3 float8 NOT NULL DEFAULT 0,
  iqr float8 NOT NULL DEFAULT 0,
  high_risk_count integer NOT NULL DEFAULT 0,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE lots ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "anon_select_lots" ON lots;
CREATE POLICY "anon_select_lots" ON lots FOR SELECT TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "anon_insert_lots" ON lots;
CREATE POLICY "anon_insert_lots" ON lots FOR INSERT TO anon, authenticated WITH CHECK (true);

DROP POLICY IF EXISTS "anon_update_lots" ON lots;
CREATE POLICY "anon_update_lots" ON lots FOR UPDATE TO anon, authenticated USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS "anon_delete_lots" ON lots;
CREATE POLICY "anon_delete_lots" ON lots FOR DELETE TO anon, authenticated USING (true);

-- Components table
CREATE TABLE IF NOT EXISTS components (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  component_id text UNIQUE NOT NULL,
  lot_id text NOT NULL REFERENCES lots(lot_id),
  component_type text NOT NULL,
  parameter_name text NOT NULL DEFAULT 'leakage_current',
  nominal_value float8 NOT NULL,
  datasheet_limit float8 NOT NULL,
  temperature float8 NOT NULL,
  voltage float8 NOT NULL,
  value_0h float8 NOT NULL,
  value_24h float8 NOT NULL,
  value_96h float8 NOT NULL,
  value_168h float8 NOT NULL,
  manufacturing_shift text NOT NULL DEFAULT 'A',
  test_date date,
  defect_label text NOT NULL DEFAULT 'normal',
  failure_type text NOT NULL DEFAULT 'none',
  created_at timestamptz DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_components_lot_id ON components(lot_id);
CREATE INDEX IF NOT EXISTS idx_components_type ON components(component_type);
CREATE INDEX IF NOT EXISTS idx_components_defect ON components(defect_label);

ALTER TABLE components ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "anon_select_components" ON components;
CREATE POLICY "anon_select_components" ON components FOR SELECT TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "anon_insert_components" ON components;
CREATE POLICY "anon_insert_components" ON components FOR INSERT TO anon, authenticated WITH CHECK (true);

DROP POLICY IF EXISTS "anon_update_components" ON components;
CREATE POLICY "anon_update_components" ON components FOR UPDATE TO anon, authenticated USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS "anon_delete_components" ON components;
CREATE POLICY "anon_delete_components" ON components FOR DELETE TO anon, authenticated USING (true);

-- Predictions table
CREATE TABLE IF NOT EXISTS predictions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  component_id text UNIQUE NOT NULL REFERENCES components(component_id),
  predicted_168h float8 NOT NULL,
  predicted_drift_96_168 float8 NOT NULL,
  predicted_margin float8 NOT NULL,
  predicted_limit_ratio float8 NOT NULL,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE predictions ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "anon_select_predictions" ON predictions;
CREATE POLICY "anon_select_predictions" ON predictions FOR SELECT TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "anon_insert_predictions" ON predictions;
CREATE POLICY "anon_insert_predictions" ON predictions FOR INSERT TO anon, authenticated WITH CHECK (true);

DROP POLICY IF EXISTS "anon_update_predictions" ON predictions;
CREATE POLICY "anon_update_predictions" ON predictions FOR UPDATE TO anon, authenticated USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS "anon_delete_predictions" ON predictions;
CREATE POLICY "anon_delete_predictions" ON predictions FOR DELETE TO anon, authenticated USING (true);

-- Risk assessments table
CREATE TABLE IF NOT EXISTS risk_assessments (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  component_id text UNIQUE NOT NULL REFERENCES components(component_id),
  statistical_score float8 NOT NULL,
  isolation_forest_score float8 NOT NULL,
  anomaly_score float8 NOT NULL,
  lot_deviation float8 NOT NULL,
  risk_score float8 NOT NULL,
  decision text NOT NULL,
  decision_reason text NOT NULL,
  risk_factors jsonb NOT NULL DEFAULT '[]'::jsonb,
  shap_values jsonb NOT NULL DEFAULT '[]'::jsonb,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE risk_assessments ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "anon_select_risk" ON risk_assessments;
CREATE POLICY "anon_select_risk" ON risk_assessments FOR SELECT TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "anon_insert_risk" ON risk_assessments;
CREATE POLICY "anon_insert_risk" ON risk_assessments FOR INSERT TO anon, authenticated WITH CHECK (true);

DROP POLICY IF EXISTS "anon_update_risk" ON risk_assessments;
CREATE POLICY "anon_update_risk" ON risk_assessments FOR UPDATE TO anon, authenticated USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS "anon_delete_risk" ON risk_assessments;
CREATE POLICY "anon_delete_risk" ON risk_assessments FOR DELETE TO anon, authenticated USING (true);
